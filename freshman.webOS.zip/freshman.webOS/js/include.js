/*
	Date - 05.06.2016
	Normurod Mamasoliev
*/

(function() {
	var scripts = [
		'jquery-1.11.2.min.js',
		'jquery-ui.min.js',
		'bootstrap.min.js',
		'default.js',
		'context-menu.js',
		'mc-ui.js',
		'jstree.js',
		'mc.js',
		'main.js',
		'jquery.contextMenu.js',
		'jquery.ui.position.js',
		'functions.js'
	];
	var styles = [
		'loader.css',
		'jquery-ui.css',
		'dialog.css',
		'bootstrap.css',
		'font-awesome.css',
		'main.css',
		'context-menu.css',
		'jstree.css',
		'jquery.contextMenu.css'
	];


	for (var d = 0; d < styles.length; d++) {
		document.writeln("<link rel=\"stylesheet\" href='css/" + styles[d] + "'/>");
	}
	
	for (var i = 0; i < scripts.length; i++) {
		document.writeln("<script type=\"text/javascript\" src='js/" + scripts[i] + "'></script>");
	}
})();