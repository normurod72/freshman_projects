/* Loading jquery */

/*
    Date - 05.06.2016
    Normurod Mamasoliev
*/

$(function (e) {
                    
    var create=new Mc_ui(), start=new MC({ 
        defaultFolder:"svg/folder.svg",
        defaultDocument:"svg/document.svg"
    }); 
    Start=function(arg){
                
        if(arg[0]=="a"&&arg[1]=="a"){
            $("#login-page").remove();
            create.desktop().panel();
            start.newApp({
                name:"Main Folder",
                id:"1",
                title:"Android root folder",
                type:"folder",
                icon:"svg/folder.svg",
                selectable:true,
                iframe:"www.inha.uz",
                body:{
                    html:"<div class='toolbar'>Toolbar</div><div class='sidebar'><div id='data'><ul><li>One</li><li>Two</li><li>node with...<ul><li>child1</li><li>child2</li></ul></li><li>Three</li></ul></div></div><div class='statusbar'></div>",
                },
                additional:{
                    /* all function you write here will 
                    be executed automatically */
                    fn:function(){
                        console.log("I am first fn");
                    }
                }
            }).newApp({
                name:"Phone",
                id:"2",
                title:"Phone calls",
                type:"contact",
                icon:"svg/call.png",
                selectable:true,
                iframe:false,
                body:{
                    html:'<div id="tabs"><ul><li><a href="#tabs-1">All calls</a></li><li><a href="#tabs-2">Incoming calls</a></li><li><a href="#tabs-3">Outgoing calls</a></li><li><a href="#tabs-4">Missed calls</a></li></ul><div id="tabs-1">'+
                    '<div class="call_info_container"><div><img src="../images/avatar.png" class="image_container" /><p class="caller-name-text"> Normurod </p><span class="number-of-calls"> (9)</span></div>'+
                    '<div><span class="caller-number-text"> +998 94 388 09 64 </span><p class="call_time">6/29/2016 16:35</p></div></div>'+'<div class="call_info_container"><div><img src="../images/avatar.png" class="image_container" /><p class="caller-name-text"> Normurod </p><span class="number-of-calls"> (9)</span></div>'+
                    '<div><span class="caller-number-text"> +998 94 388 09 64 </span><p class="call_time">6/29/2016 16:35</p></div></div>'+'<div class="call_info_container"><div><img src="../images/avatar.png" class="image_container" /><p class="caller-name-text"> Normurod </p><span class="number-of-calls"> (9)</span></div>'+
                    '<div><span class="caller-number-text"> +998 94 388 09 64 </span><p class="call_time">6/29/2016 16:35</p></div></div>'+
                    '</div><div id="tabs-2"><p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>  </div><div id="tabs-3"><p>Mauris eleifend est et turpis. Duis id erat. Suspendisse potenti. Aliquam vulputate, pede vel vehicula accumsan, mi neque rutrum erat, eu congue orci lorem eget lorem. Vestibulum non ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce sodales. Quisque eu urna vel enim commodo pellentesque. Praesent eu risus hendrerit ligula tempus pretium. Curabitur lorem enim, pretium nec, feugiat nec, luctus a, lacus.</p><p>Duis cursus. Maecenas ligula eros, blandit nec, pharetra at, semper at, magna. Nullam ac lacus. Nulla facilisi. Praesent viverra justo vitae neque. Praesent blandit adipiscing velit. Suspendisse potenti. Donec mattis, pede vel pharetra blandit, magna ligula faucibus eros, id euismod lacus dolor eget odio. Nam scelerisque. Donec non libero sed nulla mattis commodo. Ut sagittis. Donec nisi lectus, feugiat porttitor, tempor ac, tempor vitae, pede. Aenean vehicula velit eu tellus interdum rutrum. Maecenas commodo. Pellentesque nec elit. Fusce in lacus. Vivamus a libero vitae lectus hendrerit hendrerit.</p></div><div id="tabs-4">Havent been fixd yet</div></div>',
                },
            }).newApp({
                name:"Internet",
                id:"3",
                title:"Mobile Browser",
                type:"browser",
                icon:"svg/chrome.png",
                selectable:true,
                iframe:"http://eclass.inha.uz",
                body:{}
            }).newApp({
                name:"Musics",
                id:"4",
                title:"Phone musics",
                type:"app",
                icon:"svg/music.svg",
                selectable:true,
                iframe:"http://http://www.muz.uz/",
                body:{}
            }).newApp({
                name:"Camera",
                id:"5",
                title:"Phone camera",
                type:"app",
                icon:"svg/camera.svg",
                selectable:true,
                iframe:"http://http://www.muz.uz/",
                body:{
                    html:'<div id="video-container"><video id="camera-stream" width="500" autoplay="true"></video></div>',
                }
            });

            systemrun.controllability();
            systemrun.mouse_events();
            systemrun.clicks();
            search();
        }
        else{
            return $("#notify").fadeIn(600).fadeOut(3000);
        }
    }

});
    
