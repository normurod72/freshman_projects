/*
	Date - 05.06.2016
	Normurod Mamasoliev
*/

var systemrun=(function(){
	return {
		call:function(e){
			
			$(".ui-dialog").css("opacity","1");
			
			if($(".element."+e).hasClass("active-paneel-app-icon")){
				if($("#"+e+"-window").dialog("isOpen")){
					$("#"+e+"-window").dialog({minWidth:40,minHeight:40});

                            $("#"+e+"-window").parents('.ui-dialog').animate({
                                height: '40px',
                                width:'40px',
                                opacity:".2",
                                top: $(window).height() - 50,
                                left: $("."+e).offset().left
                            }, 500);
                            $("#"+e+"-window").dialog("close");

                             $("#"+e+"-window").dialog({minWidth:500,minHeight:300});
				}else{
                     $("#"+e+"-window").dialog("open");
				}
			}else{
				$("#"+e+"-window").parent(".ui-dialog").css({
						"border":"3px solid rgba(1,110,151,0.9)"
					});
				$("#"+e+"-window").dialog("open");

				
					$("#"+e+"-window").parent(".ui-dialog").find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.9)"
					});

					var parentId=$("#"+e+"-window").parent(".ui-dialog").children()[1].id;
					var parsed=parseInt(parentId);

					$("."+parsed).addClass("active-paneel-app-icon");
				
			}
						
		},

		controllability:function(){
			$( ".ui-dialog" ).on( "dialogfocus", 
				function( event, ui ) {
					$(".ui-dialog").css({
						"border":"3px solid rgba(1,110,151,0.4)"
					});
					$(".ui-dialog").find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.4)"
					});
					$(".element").removeClass("active-paneel-app-icon");

					var parentId=$(this).children()[1].id;
					var parsed=parseInt(parentId);

					$(this).css({
						"border":"3px solid rgba(1,110,151,0.9)"
					});
					$(this).find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.9)"
					});

					var parentId=$(this).children()[1].id;
					var parsed=parseInt(parentId);

					$("."+parsed).addClass("active-paneel-app-icon");

				} );

			$('#logout-btn').on('click',function(){
				window.open('http://windows.uz','_self');
			});
			
			$( ".ui-dialog" ).on("mousedown",function(){
					$(this).css({
						"border":"3px solid rgba(1,110,151,0.9)"
					});
					$(this).find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.9)"
					});
					var parentId=$(this).children()[1].id;
					var parsed=parseInt(parentId);
					$("."+parsed).addClass("active-paneel-app-icon");
			});
			$( ".ui-dialog" ).on("click",function(){
					$(this).css({
						"border":"3px solid rgba(1,110,151,0.9)"
					});
					$(this).find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.9)"
					});
					var parentId=$(this).children()[1].id;
					var parsed=parseInt(parentId);
					$("."+parsed).addClass("active-paneel-app-icon");
			});

					
			$(function(){$("#data").jstree();});			
			$(function() {$( "#tabs" ).tabs();});
		},
		mouse_events:function(){
			$(document).on("mousedown",function(event){
				if($(event.toElement)[0].id=="sortable"){
					$("#start-menu").removeClass("s-menu-active"); $("#start-menu ul").hide();
					$(".icon-holder").removeClass("icon-selected");
					$(".ui-dialog").css({
						"border":"3px solid rgba(1,110,151,0.4)"
					});
					$(".ui-dialog").find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.4)"
					});


					$(".element").removeClass("active-paneel-app-icon");
				}
				if($(event.toElement)[0].id=="panel"){
					$(".icon-holder").removeClass("icon-selected");
					$(".ui-dialog").css({
						"border":"3px solid rgba(1,110,151,0.4)"
					});
					$(".ui-dialog").find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.4)"
					});


					$(".element").removeClass("active-paneel-app-icon");
				}
				if($(event.toElement)[0].id=="taskbar-containerr"){
					$(".icon-holder").removeClass("icon-selected");
					$(".ui-dialog").css({
						"border":"3px solid rgba(1,110,151,0.4)"
					});
					$(".ui-dialog").find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.4)"
					});


					$(".element").removeClass("active-paneel-app-icon");
				}
				if($(event.toElement)[0].id=="panel-app-container"){
					$(".icon-holder").removeClass("icon-selected");
					$(".ui-dialog").css({
						"border":"3px solid rgba(1,110,151,0.4)"
					});
					$(".ui-dialog").find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.4)"
					});


					$(".element").removeClass("active-paneel-app-icon");
				}
				if($(event.toElement)[0].id=="taskbar"){
					$(".icon-holder").removeClass("icon-selected");
					$(".ui-dialog").css({
						"border":"3px solid rgba(1,110,151,0.4)"
					});
					$(".ui-dialog").find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.4)"
					});


					$(".element").removeClass("active-paneel-app-icon");
				}
				if($(event.toElement)[0].id=="panel-info-container"){
					$(".icon-holder").removeClass("icon-selected");
					$(".ui-dialog").css({
						"border":"3px solid rgba(1,110,151,0.4)"
					});
					$(".ui-dialog").find(".ui-dialog-titlebar").css({
						"background-color":"rgba(1,110,151,0.4)"
					});


					$(".element").removeClass("active-paneel-app-icon");
				}	

				

			});

			$(document).on("click",function(event){
				$('#search-btn').on('keypress',function(){
					$("#loading-thobber").css("display","inline");
					setTimeout(function(){$("#loading-thobber").css("display","none");},1500);
				});

				if($(event.toElement)[0].id=="taskbar"||$(event.toElement)[0].id=="taskbar-container"||$(event.toElement)[0].id=="start-menu"||$(event.toElement)[0].id=="search-btn"){
                        	if($("#start-menu").hasClass("s-menu-active")){
                      
                        		if($(event.toElement)[0].id=="taskbar"||$(event.toElement)[0].id=="taskbar-container"||!$(event.toElement)[0].id=="start-menu"){
                        			$("#start-menu").removeClass("s-menu-active");
										$("#start-menu ul").hide();
                        			
							  	} 
							}else{
								$(".icon-holder").removeClass("icon-selected");
								$("#start-menu").addClass("s-menu-active");
								$("#start-menu ul").show();
							}
                      
                    }else{
                    	$("#start-menu").removeClass("s-menu-active");
                    	$("#start-menu ul").hide();
                    }
			});

			if($(".ui-dialog").find(".ui-dialog-titlebar").hasClass("maximized-dialog")){
				$(this).css({
					position:"fixed !important"
				});
			}
		},

		clicks:function(){
			 $.contextMenu({
                selector: '#panel-app-container', 
                callback: function(key, options) {
                    var m = "clicked: " + key;
                    window.console && console.log(m) || alert(m); 
                },
                items: {
                    "taskbar": {name: "taskbar", icon: "<i class='fa fa-gear'></i>"},
                    "edit": {name: "Edit", icon: "edit"},
                }
            });
            
            $.contextMenu({
                selector: '#panel-info-container', 
                callback: function(key, options) {
                    var m = "clicked: " + key;
                    window.console && console.log(m) || alert(m); 
                },
                items: {
                   "edit": {name: "Edit", icon: "edit"}
                }
            });
            $.contextMenu({
                selector: '#panel-info-contaiwner', 
                callback: function(key, options) {
                    var m = "clicked: " + key;
                    window.console && console.log(m) || alert(m); 
                },
                items: {
                    "edit": {name: "Edit", icon: "edit"},
                    "cut": {name: "Cut", icon: "cut"},
                    "copy": {name: "Copy", icon: "copy"},
                    "paste": {name: "Paste", icon: "paste"},
                    "delete": {name: "Delete", icon: "delete"},
                    "sep1": "---------",
                    "quit": {name: "Quit", icon: function($element, key, item){ return 'context-menu-icon context-menu-icon-quit'; }}
                }
            });

            $("*").on('contextmenu',function(e){
            	e.preventDefault();
            });	

		}
	};
})();