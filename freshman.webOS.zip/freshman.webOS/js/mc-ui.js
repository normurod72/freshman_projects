/*
	Date - 05.06.2016
	Normurod Mamasoliev
*/
;(function($,document,window){
	Mc_ui=function(){
		this.loginPage=function(){
			mc.body.append('<div id="login-page"><div id="container"><div id="img-container"><img src="images/avatar.png"></div><div id="form-container"><form><input type="username" name="username" placeholder="username"><button id="helper" title="Click to see help!" type="button"><i class="fa fa-question"></i></button><br /><input type="password" name="password" placeholder="password"><button id="submit" type="button"><i class="fa fa-arrow-right"></i></button></form></div><p id="notify">Incorrect login or password, <br />click help to get help!</p></div><div id="bottom-bar"><div id="left"><p><img alt="logo" src="images/lg.png" width="70" style="float:left;margin-bottom:5px;" height="70"/></p></div><div id="right"><br /><p>&copy Copyright 2016</p></div></div></div>');
			(function(){var year=new Date().getFullYear(); if(year!=2016){ $("#login-page #bottom-bar #right p").append(" - "+year); }})();
            $("input[type='username']").on("focus",function(){this.placeholder = '';}).on("blur",function(){this.placeholder = 'username';});
			$("input[type='password']").on("focus",function(){this.placeholder = '';}).on("blur",function(){this.placeholder = 'password';});
				
					$("#form-container input").keydown(function(e){	
						if(e.which==13){
							return Start([$("input[type='username']").val(),$("input[type='password']").val()]);
						}
					});
					$("#submit").click(function(){
						return Start([$("input[type='username']").val(),$("input[type='password']").val()]);
					});

			return this;
		};
		this.desktop=function(){mc.body.append('<ul id="sortable"></ul>');	
		mc.body.append("<div id='phone_state_dialog'><br />&nbsp;&nbsp;<b>Model</b>: Samsung Galaxy S II<div>"); 
		mc.body.append("<div id='phone_send_dialog'><br />&nbsp;&nbsp;<b>Send anything</b>:<br /><input class='form-control' style='margin-right:5px;margin-left:5px; width:263px;' type='text' placeholder='To' /><br /><input class='form-control' style='margin-right:5px;margin-left:5px; width:263px;' type='file' /><br /><textarea style='margin-right:5px;margin-left:5px; width:263px;' rows='8' class='form-control'></textarea><div>");
		return this;};
		this.panel=function(){mc.body.append('<div id="panel"><div id="taskbar-container"><span id="taskbar"></span></div><div id="panel-app-container"></div></div><div id="panel-info-container"></div></div>').append("<div id='start-menu'><ul><li style='background-color:#383838; font-size:20px;'><img width='30' height='30' style='margin-right:5px; margin-top:-5px;' alt='user picture' src='../images/avatar.png' /> Hello User!</li><li><span class='glyphicon glyphicon-cog'></span> Settings</li><li><span class='glyphicon glyphicon-signal'></span> Mobile internet</li><li><span class='glyphicon glyphicon-usd'></span> Balance</li><li><span class='glyphicon glyphicon-wrench'></span> Set restrictions</li><li onclick='show_send_state()'><span class='glyphicon glyphicon-send'></span> Send</li><li onclick='show_phone_state()'><span class='glyphicon glyphicon-phone'></span> Phone state</li><li><span class='glyphicon glyphicon-search'></span> <input type='search' list='datalist' placeholder='search' id='search-btn' /><img width='15' height='15' src='../images/throbber.gif' id='loading-thobber' style='display:none;' /></li><li id='logout-btn'><span class='glyphicon glyphicon-off'></span> Logout</li></ul></div>"); return this;	};
	}
})(jQuery,document,window);