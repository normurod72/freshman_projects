/*
    Date - 05.06.2016
    Normurod Mamasoliev
*/

$(function (e) {
    ;(function($){
        MC=function(arg,app){
            this.defaut_icons=arg;
            this.app_details=app;
        }

        MC.prototype={
                newApp:function(app){
                    if(typeof app.additional!=="undefined"){
                        $.each(app.additional,function(key,value){
                            this();
                        });
                    }
                    app.windowId=app.id+"-window";
                $("#sortable").append("<li class='ui-state-default'><div id="+app.id+" class='icon-holder'><figure><img title="+app.title+" src="+((app.icon=="undefined"||app.icon==""||app.icon==null)?arg.defaultFolder:app.icon)+" /><figcaption>"+((app.name=="undefined"||app.name==""||app.name==null)?"untitled":app.name)+"</figcaption></figure></div></li>");
                    this.defaults(app);
                    return this;
            },


                defaults:function(app){
                    $.contextMenu({
                        selector: '#'+app.id, 
                        callback: function(key, options) {
                            if(key=="open"){
                                $("#"+app.id).dblclick();
                            }
                        },
                        items: {
                            "open": {name: "open", icon: ""},
                            "sep1": "---------",
                            "cut": {name: "Cut", icon: "cut"},
                            "copy": {name: "Copy", icon: "copy"},
                            "paste": {name: "Paste", icon: "paste"},
                            "rename": {name: "Rename", icon: "edit"},
                            
                        }
                });

                
                $('#phone_state_dialog').dialog({
                    autoOpen:false,
                    width:280,
                    resizable:false,
                    draggable:true,
                    height:360,
                    title:"Statusbar",
                    buttons:{
                        ok:function(){
                            $(this).dialog('close');
                        },
                        cancel:function(){
                            $(this).dialog('close');  
                        }
                    }
                });
                 $('#phone_send_dialog').dialog({
                    autoOpen:false,
                    width:280,
                    resizable:false,
                    draggable:true,
                    height:360,
                    title:"Send",
                    buttons:{
                        cancel:function(){
                            $(this).dialog('close');
                        },
                        send:function(){
                            $(this).dialog('close');
                        }
                    }
                });

                $( "#sortable" ).sortable().disableSelection().selectable({
                    stop: function() {
                        var result=0;// = $( "#select-result" ).empty();
                        $( ".ui-selected", this ).each(function() {
                          var index = $( "#selectable li" ).index( this );
                          result+=index;
                          //result.append( " #" + ( index + 1 ) );
                          //console.log(result);
                        });
                    }
                });

                $("#mc").append('<div id='+app.windowId+'></div>');
                $("#"+app.windowId).parent().children(".ui-dialog-titlebar")
        .append('<img class="app-title-icon" src="'+app.icon+'" />');
                $("#"+app.windowId).css({
                    height:"100% !important"
                });
                var dialog=$("#"+app.windowId).dialog({
                    autoOpen: false, 
                    width:750,
                    closeOnEscape:false,
                    height:500,
                    minHeight:300,
                    minWidth:500,
                    title:app.name,   
                    buttons:{
                    },
                });
                $("#"+app.windowId).append(app.body.html);
                        
                this.doubleClick($("#"+app.id),$("#"+app.windowId),app);              

                this.generals(app,dialog);
            //---------------------------------------------------------
                if(app.selectable){
                    $("#"+app.id).click(function(e){
                     
                            $(".icon-holder").removeClass("icon-selected");
                        if($(".icon-holder").hasClass("icon-selected")){
                            $(this).addClass("icon-selected");
                        }
                        else{
                            $(this).addClass("icon-selected");
                        }
                    });
                     $("#"+app.id).on('contextmenu',function(){
                          $(".icon-holder").removeClass("icon-selected");
                        if($(".icon-holder").hasClass("icon-selected")){
                            $(this).addClass("icon-selected");
                        }
                        else{
                            $(this).addClass("icon-selected");
                        }   


                     });
                    }         
                },
                generals:function(app,dialog){

                    var titlebar = dialog.parents('.ui-dialog').find('.ui-dialog-titlebar');
                    $('<button id="close"><i class="fa fa-remove"></i></button>')
                        .appendTo(titlebar)
                        .click(function() {
                            dialog.dialog("close");
                            $("."+app.id).remove();
                        });

                    $('<button id="maximize"><i class="fa fa-square-o"></i></button>')
                    .appendTo(titlebar)
                        .click(function() {
                            
                            if($(this).hasClass("maximized-dialog")){
                                $(this).parents('.ui-dialog').animate({
                                height: neededVal[3],
                                width:neededVal[2],
                                top: neededVal[1],
                                left: neededVal[0],
                            }, 250);
                                $(this).removeClass("maximized-dialog");
                                $(".toolbar").css({
                                    position:"relative",
                                    left:"0px",
                                    right:"0px",
                                    width:"100%",
                                });
                                 $(".sidebar").css({
                                    position:"relative",
                                    left:"0px",
                                    height:"100%",

                                });
                                  $(".statusbar").css({
                                    position:"relative",
                                    left:"0px",
                                    right:"0px",
                                    bottom:"0px"
                                });
                            }else{
                                neededVal=[$(this).parents('.ui-dialog').offset().left,$(this).parents('.ui-dialog').offset().top,$(this).parents('.ui-dialog').width(),$(this).parents('.ui-dialog').height()];
                               
                              $(this).parents('.ui-dialog').animate({
                                height: $(window).height() - 40,
                                width:$(window).width(),
                                top: "0px",
                                left: "0px",
                            }, 250);
                            $(this).addClass("maximized-dialog");  
                            }
                             
                        });

                         $(".ui-dialog-titlebar").dblclick(function(e) {
                                         e.stopImmediatePropagation();
                            $($(this).children()[2]).click();
                        });
                        
                    $("<button id='minimize'><i class='fa fa-minus'></button>")
                    .appendTo(titlebar)
                        .click(function() {                           
                                $("#"+app.id+"-window").dialog({minWidth:40,minHeight:40});
                            $(this).parents('.ui-dialog').animate({
                                height: '40px',
                                width:'40px',
                                opacity:".2",
                                top: $(window).height() - 50,
                                left: $("."+app.id).offset().left
                            }, 500);

                            $("#"+app.id+"-window").dialog("close");

                             $("#"+app.id+"-window").dialog({minWidth:500,minHeight:300});
                        });


                     $(".ui-dialog-titlebar-close").remove();

                },
                doubleClick:function(id,winId,app){
                    id.dblclick(function(){
                    
                    if(!$(".element").hasClass(app.id)){
                        $("#panel-app-container").
                        append("<div class='element "+app.id+"' onmousedown='systemrun.call("+app.id+")'><img class='app-icon' src='"+app.icon+"' ></img></div>");
                    }
                         $(".ui-dialog").css("opacity","1");
                        $("#maximize").removeClass("maximized-dialog");
                        winId.dialog("open");
                        systemrun.controllability();                        
                    });
                },
               
        }
    })(jQuery);
});