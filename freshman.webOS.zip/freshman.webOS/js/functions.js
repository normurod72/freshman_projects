/*
	Date - 05.06.2016
	Normurod Mamasoliev
*/

function search(){
	mc.body.append('<datalist id="datalist"><option value="Nothing"><option value="Active"><option value="Area"><option value="button"><option value="text"><option value="Boring"><option value="Football"></datalist>');
}
function show_phone_state(){
	$('#phone_state_dialog').dialog('open');
}
function show_send_state(){
	$('#phone_send_dialog').dialog('open');
}