﻿=== RuneScape's Ingame Cursors - Full Edition Release (Version 1) Cursor Set ===

By: Apocalypsing (http://www.rw-designer.com/user/3539) vandermeer94@hotmail.com

Download: http://www.rw-designer.com/cursor-set/runescape-ingame-cursors

Author's decription:

Ready to be used anywhere outside of RuneScape on your computer, these cursors are based off the recently added ingame cursors. These cursors also have a built-in shadow, as Windows unfortunately does not support the 'enable pointer shadow' option with customised cursors, this is also a full cursor set. And I hope you like them. 
I am currently not taking cursor requests because I am busy at the moment with other things in life.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.