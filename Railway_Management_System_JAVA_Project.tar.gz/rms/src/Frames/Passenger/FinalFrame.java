/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Frames.Passenger;

import Classes.DataBase;
import Classes.Passenger;
import Frames.Main;
import com.toedter.calendar.JDateChooser;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author 2016
 */
public class FinalFrame extends javax.swing.JFrame {

    /**
     * Creates new form FinalFrame
     */
    int[] discounts={30,40,42,0};
    private String ticket_number;
    
    private final DataBase db=new DataBase();
    public FinalFrame(String FirstName, String LastName, String MiddleName, JDateChooser dob,String address, String p_number,
            String p_type,String departure_id,String arrival_id,boolean round_trip,int c_number,int s_number, 
            int ticket_price,String class_type_d,String class_type_a) {
        initComponents();
        setLocationRelativeTo(null);
        
        System.out.println(p_number);
        
        String queryPass="SELECT id FROM passenger_info WHERE passport_number='"+p_number+"' ";
        System.out.println(queryPass);
        try
        {
          ResultSet pass=db.executeSelectQuery(queryPass);
          while (pass.next())
          {
              System.out.println(pass.getString("id"));
              this.ticket_number="RW000"+pass.getString("id");
              TicketId.setText(this.ticket_number);
          }
        }catch(SQLException c)
        {
            Logger.getLogger(Passenger.class.getName()).log(Level.SEVERE, null, c);
        }
        CabinNum.setText(String.valueOf(c_number));
        SeatNum.setText(String.valueOf(s_number));
        PassName.setText(String.valueOf(FirstName+" "+LastName+" "+MiddleName));
        PassType.setText(String.valueOf(p_type));
        
        
        
        
        String query2="SELECT * FROM trains WHERE id='"+departure_id+"'";
            
            try {
                ResultSet d_data=db.executeSelectQuery(query2);
                while(d_data.next()){
                    TripType.setText("One way");
                    DepartureDate.setText(d_data.getString("departure_date")+"/"+d_data.getString("departure_time"));
                    TrId.setText(d_data.getString("train_number"));
                    TrName.setText(d_data.getString("train_name"));
                    TrainRoute1.setText(d_data.getString("train_route1"));
                    TrainRoute2.setText(d_data.getString("train_route2"));
                    if (p_type.equals("Student"))
                    {
                        Price.setText(String.valueOf(ticket_price-ticket_price*discounts[0]/100));
                        Discount.setText(String.valueOf(discounts[0]+"%"));
                    }else if (p_type.equals("Military worker"))
                    {
                        Price.setText(String.valueOf(ticket_price-ticket_price*discounts[1]/100));
                        Discount.setText(String.valueOf(discounts[1]+"%"));
                    }else if (p_type.equals("Railway worker"))
                    {
                        Price.setText(String.valueOf(ticket_price-ticket_price*discounts[2]/100));
                        Discount.setText(String.valueOf(discounts[2]+"%"));
                    }else
                    {
                        Price.setText(String.valueOf(ticket_price-ticket_price*discounts[3]/100));
                        Discount.setText(String.valueOf(discounts[3]+"%"));
                    }
                    
                }
            } catch (SQLException ex) {
                Logger.getLogger(Passenger.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (round_trip)
                    {
                        String query3="SELECT * FROM trains WHERE id='"+departure_id+"'";
            
            try {
                ResultSet d_data=db.executeSelectQuery(query3);
                while(d_data.next()){
                        TripType.setText("Round Trip");
                        ACabinNum.setText(String.valueOf(c_number));
                        ASeatNum.setText(String.valueOf(s_number));
                        APassName.setText(String.valueOf(FirstName+" "+LastName+" "+MiddleName));
                        APassType.setText(String.valueOf(p_type));
                        ADepDate.setText(d_data.getString("departure_date")+"/"+d_data.getString("departure_time"));
                        ATrId.setText(d_data.getString("train_number"));
                        ATrName.setText(d_data.getString("train_name"));
                        ATrRoute1.setText(d_data.getString("train_route1"));
                        ATrRoute2.setText(d_data.getString("train_route2"));
                    if (p_type.equals("Student"))
                    {
                        ADiscount.setText(String.valueOf(discounts[0]+"%"));
                    }else if (p_type.equals("Military worker"))
                    {
                        ADiscount.setText(String.valueOf(discounts[1]+"%"));
                    }else if (p_type.equals("Railway worker"))
                    {
                        ADiscount.setText(String.valueOf(discounts[2]+"%"));
                    }else
                    {
                        ADiscount.setText(String.valueOf(discounts[3]+"%"));
                    }
                    
                }
            } catch (SQLException ex) {
                Logger.getLogger(Passenger.class.getName()).log(Level.SEVERE, null, ex);
            }
                        
                    }else
            {
                ArrivalPanel.setVisible(false);
            }
    }
    public FinalFrame() {
        initComponents();
        setLocationRelativeTo(null);
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel16 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        TicketPanel = new javax.swing.JPanel();
        DietelsLabel1 = new javax.swing.JLabel();
        PassName = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        CabinNum = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        SeatNum = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        DepartureDate = new javax.swing.JLabel();
        TrId = new javax.swing.JLabel();
        TrName = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        TrainRoute1 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        TrainRoute2 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        PassType = new javax.swing.JLabel();
        TripType = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel21 = new javax.swing.JLabel();
        Price = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        Discount = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        ArrivalPanel = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        ACabinNum = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        ASeatNum = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        ADiscount = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        ADepDate = new javax.swing.JLabel();
        ATrId = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        ATrName = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        ATrRoute1 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        ATrRoute2 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        APassType = new javax.swing.JLabel();
        APassName = new javax.swing.JLabel();
        TicketId = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        statement = new javax.swing.JCheckBox();
        jButton2 = new javax.swing.JButton();
        Print = new javax.swing.JButton();
        DietelsLabel = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel16.setText("Andijan");

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel26.setText("42%");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        TicketPanel.setBackground(new java.awt.Color(252, 251, 251));
        TicketPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        DietelsLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        DietelsLabel1.setForeground(new java.awt.Color(51, 51, 51));
        DietelsLabel1.setText("TICKET №");

        PassName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        PassName.setText("Normurod Mamasoliev Rahmatillo o'g'li");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("CN ");

        CabinNum.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        CabinNum.setText("12");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("SN");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("DP /");

        SeatNum.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        SeatNum.setText("42");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("D/T:");

        DepartureDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        DepartureDate.setText("Dec 26,2016 / 22:30:00");

        TrId.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        TrId.setText("TR456");

        TrName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        TrName.setText("Afrosiyob poyezdi");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("R:");

        TrainRoute1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        TrainRoute1.setText("Tashkent");

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("from");

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel14.setText("to");

        TrainRoute2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        TrainRoute2.setText("Andijan");

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel17.setText("NSM:");

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel18.setText("Ptype:");

        PassType.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        PassType.setText("Railway worker");

        TripType.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
        TripType.setText("Round Trip");

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel21.setText("P/");

        Price.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Price.setText("32500");

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel23.setText("soums");

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel24.setText("DA/");

        Discount.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Discount.setText("42%");

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel27.setText("Must go train station 20 minutes before time.");

        jLabel28.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel28.setText("CN ");

        ACabinNum.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ACabinNum.setText("12");

        jLabel30.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel30.setText("SN");

        jLabel33.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel33.setText("AR /");

        ASeatNum.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ASeatNum.setText("42");

        jLabel36.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel36.setText("DA/");

        ADiscount.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ADiscount.setText("42%");

        jLabel38.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel38.setText("D/T:");

        ADepDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ADepDate.setText("Dec 26,2016 / 22:30:00");

        ATrId.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ATrId.setText("TR456");

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel41.setText("Must go train station 20 minutes before time.");

        ATrName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ATrName.setText("Afrosiyob poyezdi");

        jLabel43.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel43.setText("R:");

        ATrRoute1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ATrRoute1.setText("Tashkent");

        jLabel45.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel45.setText("from");

        jLabel46.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel46.setText("to");

        ATrRoute2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ATrRoute2.setText("Andijan");

        jLabel48.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel48.setText("NSM:");

        jLabel49.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel49.setText("Ptype:");

        APassType.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        APassType.setText("Railway worker");

        APassName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        APassName.setText("Normurod Mamasoliev Rahmatillo o'g'li");

        javax.swing.GroupLayout ArrivalPanelLayout = new javax.swing.GroupLayout(ArrivalPanel);
        ArrivalPanel.setLayout(ArrivalPanelLayout);
        ArrivalPanelLayout.setHorizontalGroup(
            ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ArrivalPanelLayout.createSequentialGroup()
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ArrivalPanelLayout.createSequentialGroup()
                        .addComponent(jLabel28)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ACabinNum)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ASeatNum)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel38)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ADepDate)
                        .addGap(101, 101, 101))
                    .addComponent(ATrId, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(31, 31, 31))
            .addGroup(ArrivalPanelLayout.createSequentialGroup()
                .addGroup(ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ArrivalPanelLayout.createSequentialGroup()
                        .addGroup(ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(ArrivalPanelLayout.createSequentialGroup()
                                .addComponent(jLabel48)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(APassName)
                                .addGap(22, 22, 22)
                                .addComponent(jLabel49))
                            .addGroup(ArrivalPanelLayout.createSequentialGroup()
                                .addComponent(ATrName)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel43)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel45)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ATrRoute1)
                                .addGap(28, 28, 28)
                                .addComponent(jLabel46)))
                        .addGroup(ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ArrivalPanelLayout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(ATrRoute2))
                            .addGroup(ArrivalPanelLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(APassType))))
                    .addGroup(ArrivalPanelLayout.createSequentialGroup()
                        .addGap(111, 111, 111)
                        .addComponent(jLabel36)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ADiscount)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel41)))
                .addGap(0, 20, Short.MAX_VALUE))
        );
        ArrivalPanelLayout.setVerticalGroup(
            ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ArrivalPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(ACabinNum)
                    .addComponent(jLabel30)
                    .addComponent(jLabel33)
                    .addComponent(ASeatNum)
                    .addComponent(jLabel38)
                    .addComponent(ADepDate)
                    .addComponent(ATrId))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ATrName)
                    .addComponent(jLabel43)
                    .addComponent(ATrRoute1)
                    .addComponent(jLabel45)
                    .addComponent(jLabel46)
                    .addComponent(ATrRoute2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel48)
                    .addComponent(APassName)
                    .addComponent(jLabel49)
                    .addComponent(APassType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ArrivalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36)
                    .addComponent(ADiscount)
                    .addComponent(jLabel41))
                .addContainerGap())
        );

        TicketId.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        TicketId.setForeground(new java.awt.Color(51, 51, 51));
        TicketId.setText("RW00021");

        javax.swing.GroupLayout TicketPanelLayout = new javax.swing.GroupLayout(TicketPanel);
        TicketPanel.setLayout(TicketPanelLayout);
        TicketPanelLayout.setHorizontalGroup(
            TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TicketPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ArrivalPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(TicketPanelLayout.createSequentialGroup()
                        .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(TicketPanelLayout.createSequentialGroup()
                                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(TicketPanelLayout.createSequentialGroup()
                                        .addComponent(jLabel17)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(PassName)
                                        .addGap(22, 22, 22)
                                        .addComponent(jLabel18))
                                    .addGroup(TicketPanelLayout.createSequentialGroup()
                                        .addComponent(TrName)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel11)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(TrainRoute1)
                                        .addGap(28, 28, 28)
                                        .addComponent(jLabel14)))
                                .addGap(18, 18, 18)
                                .addComponent(PassType))
                            .addComponent(jLabel5)
                            .addGroup(TicketPanelLayout.createSequentialGroup()
                                .addComponent(jLabel21)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Price)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel23)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel24)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Discount)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel27))
                            .addGroup(TicketPanelLayout.createSequentialGroup()
                                .addComponent(TripType)
                                .addGap(118, 118, 118)
                                .addComponent(DietelsLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(TicketId)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(TicketPanelLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(TicketPanelLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CabinNum)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SeatNum)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(DepartureDate)
                        .addGap(101, 101, 101))
                    .addComponent(TrId)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(TicketPanelLayout.createSequentialGroup()
                        .addComponent(TrainRoute2)
                        .addGap(46, 46, 46)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TicketPanelLayout.setVerticalGroup(
            TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TicketPanelLayout.createSequentialGroup()
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TicketPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DietelsLabel1)
                            .addComponent(TicketId)))
                    .addGroup(TicketPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(TripType)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(CabinNum)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(SeatNum)
                    .addComponent(jLabel7)
                    .addComponent(DepartureDate)
                    .addComponent(TrId))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TrName)
                    .addComponent(jLabel11)
                    .addComponent(TrainRoute1)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14)
                    .addComponent(TrainRoute2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(PassName)
                    .addComponent(jLabel18)
                    .addComponent(PassType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(Price)
                    .addComponent(jLabel23)
                    .addComponent(jLabel24)
                    .addComponent(Discount)
                    .addComponent(jLabel27))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ArrivalPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton1.setText("Finish");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        statement.setText("I have fully read so,  I accept all details written above.");

        jButton2.setText("Get image");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        Print.setText("Print");

        DietelsLabel.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        DietelsLabel.setForeground(new java.awt.Color(0, 102, 0));
        DietelsLabel.setText("Congratulations!");

        jLabel54.setForeground(new java.awt.Color(255, 51, 0));
        jLabel54.setText("You have to bring two copies of this page!");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(statement)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(TicketPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel54)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Print, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(180, 180, 180)
                .addComponent(DietelsLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(DietelsLabel)
                .addGap(18, 18, 18)
                .addComponent(TicketPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(statement)
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(Print))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel54)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if(statement.isSelected()){
            Main obj=new Main();
            obj.setVisible(true);
            dispose();
        }else{
            JOptionPane.showMessageDialog(null, "Select the checkbox first!");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if(statement.isSelected()){
            takeSnapShot(TicketPanel);
            JOptionPane.showMessageDialog(null, "You have got image");
        }else{
            JOptionPane.showMessageDialog(null, "Select the checkbox first!");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    void takeSnapShot(JPanel panel){
        BufferedImage bufImage=new BufferedImage(panel.getSize().width,panel.getSize().height,BufferedImage.TYPE_INT_RGB);
        panel.paint(bufImage.createGraphics());
        File imageFile=new File("C://Users/2016/desktop/ticket_"+this.ticket_number+".jpeg");
        try{
            imageFile.createNewFile();
            ImageIO.write(bufImage, "jpeg", imageFile);
        }catch(Exception ex){
        }
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FinalFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FinalFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FinalFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FinalFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FinalFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ACabinNum;
    private javax.swing.JLabel ADepDate;
    private javax.swing.JLabel ADiscount;
    private javax.swing.JLabel APassName;
    private javax.swing.JLabel APassType;
    private javax.swing.JLabel ASeatNum;
    private javax.swing.JLabel ATrId;
    private javax.swing.JLabel ATrName;
    private javax.swing.JLabel ATrRoute1;
    private javax.swing.JLabel ATrRoute2;
    private javax.swing.JPanel ArrivalPanel;
    private javax.swing.JLabel CabinNum;
    private javax.swing.JLabel DepartureDate;
    private javax.swing.JLabel DietelsLabel;
    private javax.swing.JLabel DietelsLabel1;
    private javax.swing.JLabel Discount;
    private javax.swing.JLabel PassName;
    private javax.swing.JLabel PassType;
    private javax.swing.JLabel Price;
    private javax.swing.JButton Print;
    private javax.swing.JLabel SeatNum;
    private javax.swing.JLabel TicketId;
    private javax.swing.JPanel TicketPanel;
    private javax.swing.JLabel TrId;
    private javax.swing.JLabel TrName;
    private javax.swing.JLabel TrainRoute1;
    private javax.swing.JLabel TrainRoute2;
    private javax.swing.JLabel TripType;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JCheckBox statement;
    // End of variables declaration//GEN-END:variables
}
