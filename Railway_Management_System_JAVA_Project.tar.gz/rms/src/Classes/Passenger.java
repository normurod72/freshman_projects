/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import Frames.Passenger.FinalFrame;
import static Frames.Passenger.PaymentOptions.randInt;
import com.toedter.calendar.JDateChooser;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import lu.tudor.santec.jtimechooser.JTimeChooser;

/**
 *
 * @author 2016
 */
public class Passenger extends RailwayUser{

    JComboBox route1;
    JComboBox route2;
    JDateChooser date;
    JComboBox time1;
    JComboBox time2;
    String DepartureId;
    String ArrivalId;
    int cNumb;
    int SNumb;
    int TicketPrice;
    String DepartureClassSize;
    String ArrivalClassSize;
    boolean roundTrip;
    private final DataBase db= new DataBase();
    private String address;
    private String passportNumber;
    private String passengerType;
    
    public Passenger(String FirstName, String LastName, String MiddleName, JDateChooser dob,String address, String p_number,
            String p_type,String departure_id,String arrival_id,boolean round_trip,int c_number,int s_number, 
            int ticket_price,String class_type_d,String class_type_a) {
        
        super(FirstName, LastName, MiddleName, dob);
        this.roundTrip=round_trip;
        this.address=address;
        this.passportNumber=p_number;
        this.DepartureId=departure_id;
        this.cNumb=c_number;
        this.SNumb=s_number;
        this.TicketPrice=ticket_price;
        this.DepartureClassSize=class_type_d;
        if(round_trip){
            this.ArrivalClassSize=class_type_a;
            this.ArrivalId=arrival_id;
        }
        this.passengerType=p_type;
    }

    public Passenger(JComboBox route1, JComboBox route2, JDateChooser date, JComboBox time1, JComboBox time2) {
        super(null, null, null, null);
        this.route1 = route1;
        this.route2 = route2;
        this.date = date;
        this.time1 = time1;
        this.time2 = time2;
    }
    
    public FinalFrame hardWork(){
        if(this.roundTrip){
            String query="INSERT INTO passenger_info  (first_name,last_name,middle_name,dob,passport_number,home_address,passenger_type,d_train_id,a_train_id,round_trip,c_number,s_number,ticket_price) VALUES('"+FirstName+"', '"+LastName+"', '"+MiddleName+"','"+((JTextField)dob.getDateEditor().getUiComponent()).getText()+"','"+passportNumber+"', '"+address+"', '"+passengerType+"','"+DepartureId+"','"+ArrivalId+"',"+true+","+cNumb+","+SNumb +","+TicketPrice+") ";
            String query2="SELECT * FROM trains WHERE id='"+this.DepartureId+"'";
            ResultSet d_data=db.executeSelectQuery(query2);
            try {
                while(d_data.next()){
                    
                    String query3="";
                    if(this.DepartureClassSize.equals("Number Coach Seat")){
                        query3="UPDATE trains SET train_name='"+d_data.getString("train_name")+"',train_number='"+d_data.getString("train_number")+"',train_route1='"+d_data.getString("train_route1")+"',train_route2='"+d_data.getString("train_route2")+"',departure_time='"+d_data.getString("departure_time")+"',arrival_time='"+d_data.getString("arrival_time")+"',departure_date='"+d_data.getString("departure_date")+"',arrival_date='"+d_data.getString("arrival_date")+"',coach_class='"+(Integer.parseInt(d_data.getString("coach_class"))-1)+"',bussiness_class='"+(Integer.parseInt(d_data.getString("bussiness_class")))+"',first_class='"+(Integer.parseInt(d_data.getString("first_class")))+"',coach_price='"+d_data.getString("coach_price")+"',bussiness_price='"+d_data.getString("bussiness_price")+"',first_price='"+d_data.getString("first_price")+"', coach_reserved_seats='"+(Integer.parseInt(d_data.getString("coach_reserved_seats"))+1)+"', bussiness_reserved_seats='"+(Integer.parseInt(d_data.getString("bussiness_reserved_seats")))+"', first_reserved_seats='"+(Integer.parseInt(d_data.getString("first_reserved_seats")))+"' WHERE id='"+this.DepartureId+"'";               
                    }else if(this.DepartureClassSize.equals("Number Bussiness Seat")){
                        query3="UPDATE trains SET train_name='"+d_data.getString("train_name")+"',train_number='"+d_data.getString("train_number")+"',train_route1='"+d_data.getString("train_route1")+"',train_route2='"+d_data.getString("train_route2")+"',departure_time='"+d_data.getString("departure_time")+"',arrival_time='"+d_data.getString("arrival_time")+"',departure_date='"+d_data.getString("departure_date")+"',arrival_date='"+d_data.getString("arrival_date")+"',coach_class='"+(Integer.parseInt(d_data.getString("coach_class")))+"',bussiness_class='"+(Integer.parseInt(d_data.getString("bussiness_class"))-1)+"',first_class='"+(Integer.parseInt(d_data.getString("first_class")))+"',coach_price='"+d_data.getString("coach_price")+"',bussiness_price='"+d_data.getString("bussiness_price")+"',first_price='"+d_data.getString("first_price")+"', coach_reserved_seats='"+(Integer.parseInt(d_data.getString("coach_reserved_seats")))+"', bussiness_reserved_seats='"+(Integer.parseInt(d_data.getString("bussiness_reserved_seats"))+1)+"', first_reserved_seats='"+(Integer.parseInt(d_data.getString("first_reserved_seats")))+"' WHERE id='"+this.DepartureId+"'";               
                    }else if(this.DepartureClassSize.equals("Number First Seat")){
                        query3="UPDATE trains SET train_name='"+d_data.getString("train_name")+"',train_number='"+d_data.getString("train_number")+"',train_route1='"+d_data.getString("train_route1")+"',train_route2='"+d_data.getString("train_route2")+"',departure_time='"+d_data.getString("departure_time")+"',arrival_time='"+d_data.getString("arrival_time")+"',departure_date='"+d_data.getString("departure_date")+"',arrival_date='"+d_data.getString("arrival_date")+"',coach_class='"+(Integer.parseInt(d_data.getString("coach_class")))+"',bussiness_class='"+(Integer.parseInt(d_data.getString("bussiness_class")))+"',first_class='"+(Integer.parseInt(d_data.getString("first_class"))-1)+"',coach_price='"+d_data.getString("coach_price")+"',bussiness_price='"+d_data.getString("bussiness_price")+"',first_price='"+d_data.getString("first_price")+"', coach_reserved_seats='"+(Integer.parseInt(d_data.getString("coach_reserved_seats")))+"', bussiness_reserved_seats='"+(Integer.parseInt(d_data.getString("bussiness_reserved_seats")))+"', first_reserved_seats='"+(Integer.parseInt(d_data.getString("first_reserved_seats"))+1)+"' WHERE id='"+this.DepartureId+"'";               
                    }
                    
                    db.executeQuery(query3);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Passenger.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            String query4="SELECT * FROM trains WHERE id='"+this.DepartureId+"'";
            ResultSet a_data=db.executeSelectQuery(query4);
            try {
                while(a_data.next()){
                    
                    String query5="";
                    if(this.DepartureClassSize.equals("Number Coach Seat")){
                        query5="UPDATE trains SET train_name='"+a_data.getString("train_name")+"',train_number='"+a_data.getString("train_number")+"',train_route1='"+a_data.getString("train_route1")+"',train_route2='"+a_data.getString("train_route2")+"',departure_time='"+a_data.getString("departure_time")+"',arrival_time='"+a_data.getString("arrival_time")+"',departure_date='"+a_data.getString("departure_date")+"',arrival_date='"+a_data.getString("arrival_date")+"',coach_class='"+(Integer.parseInt(a_data.getString("coach_class"))-1)+"',bussiness_class='"+(Integer.parseInt(a_data.getString("bussiness_class")))+"',first_class='"+(Integer.parseInt(a_data.getString("first_class")))+"',coach_price='"+a_data.getString("coach_price")+"',bussiness_price='"+a_data.getString("bussiness_price")+"',first_price='"+a_data.getString("first_price")+"', coach_reserved_seats='"+(Integer.parseInt(a_data.getString("coach_reserved_seats"))+1)+"', bussiness_reserved_seats='"+(Integer.parseInt(a_data.getString("bussiness_reserved_seats")))+"', first_reserved_seats='"+(Integer.parseInt(a_data.getString("first_reserved_seats")))+"' WHERE id='"+this.DepartureId+"'";               
                    }else if(this.DepartureClassSize.equals("Number Bussiness Seat")){
                        query5="UPDATE trains SET train_name='"+a_data.getString("train_name")+"',train_number='"+a_data.getString("train_number")+"',train_route1='"+a_data.getString("train_route1")+"',train_route2='"+a_data.getString("train_route2")+"',departure_time='"+a_data.getString("departure_time")+"',arrival_time='"+a_data.getString("arrival_time")+"',departure_date='"+a_data.getString("departure_date")+"',arrival_date='"+a_data.getString("arrival_date")+"',coach_class='"+(Integer.parseInt(a_data.getString("coach_class")))+"',bussiness_class='"+(Integer.parseInt(a_data.getString("bussiness_class"))-1)+"',first_class='"+(Integer.parseInt(a_data.getString("first_class")))+"',coach_price='"+a_data.getString("coach_price")+"',bussiness_price='"+a_data.getString("bussiness_price")+"',first_price='"+a_data.getString("first_price")+"', coach_reserved_seats='"+(Integer.parseInt(a_data.getString("coach_reserved_seats")))+"', bussiness_reserved_seats='"+(Integer.parseInt(a_data.getString("bussiness_reserved_seats"))+1)+"', first_reserved_seats='"+(Integer.parseInt(a_data.getString("first_reserved_seats")))+"' WHERE id='"+this.DepartureId+"'";               
                    }else if(this.DepartureClassSize.equals("Number First Seat")){
                        query5="UPDATE trains SET train_name='"+a_data.getString("train_name")+"',train_number='"+a_data.getString("train_number")+"',train_route1='"+a_data.getString("train_route1")+"',train_route2='"+a_data.getString("train_route2")+"',departure_time='"+a_data.getString("departure_time")+"',arrival_time='"+a_data.getString("arrival_time")+"',departure_date='"+a_data.getString("departure_date")+"',arrival_date='"+a_data.getString("arrival_date")+"',coach_class='"+(Integer.parseInt(a_data.getString("coach_class")))+"',bussiness_class='"+(Integer.parseInt(a_data.getString("bussiness_class")))+"',first_class='"+(Integer.parseInt(a_data.getString("first_class"))-1)+"',coach_price='"+a_data.getString("coach_price")+"',bussiness_price='"+a_data.getString("bussiness_price")+"',first_price='"+a_data.getString("first_price")+"', coach_reserved_seats='"+(Integer.parseInt(a_data.getString("coach_reserved_seats")))+"', bussiness_reserved_seats='"+(Integer.parseInt(a_data.getString("bussiness_reserved_seats")))+"', first_reserved_seats='"+(Integer.parseInt(a_data.getString("first_reserved_seats"))+1)+"' WHERE id='"+this.DepartureId+"'";               
                    }
                    
                    db.executeQuery(query5);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Passenger.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            
            db.executeQuery(query);
        }else{
            String query2="SELECT * FROM trains WHERE id='"+this.DepartureId+"'";
            ResultSet d_data=db.executeSelectQuery(query2);
            String query="INSERT INTO passenger_info  (first_name,last_name,middle_name,dob,passport_number,home_address,passenger_type,d_train_id,a_train_id,round_trip,c_number,s_number,ticket_price) VALUES('"+FirstName+"', '"+LastName+"', '"+MiddleName+"','"+((JTextField)dob.getDateEditor().getUiComponent()).getText()+"','"+passportNumber+"', '"+address+"', '"+passengerType+"','"+DepartureId+"',"+null+","+false+","+cNumb+","+SNumb +","+TicketPrice+") ";
            try {
                while(d_data.next()){
                    
                    String query3="";
                    if(this.DepartureClassSize.equals("Number Coach Seat")){
                        query3="UPDATE trains SET train_name='"+d_data.getString("train_name")+"',train_number='"+d_data.getString("train_number")+"',train_route1='"+d_data.getString("train_route1")+"',train_route2='"+d_data.getString("train_route2")+"',departure_time='"+d_data.getString("departure_time")+"',arrival_time='"+d_data.getString("arrival_time")+"',departure_date='"+d_data.getString("departure_date")+"',arrival_date='"+d_data.getString("arrival_date")+"',coach_class='"+(Integer.parseInt(d_data.getString("coach_class"))-1)+"',bussiness_class='"+(Integer.parseInt(d_data.getString("bussiness_class")))+"',first_class='"+(Integer.parseInt(d_data.getString("first_class")))+"',coach_price='"+d_data.getString("coach_price")+"',bussiness_price='"+d_data.getString("bussiness_price")+"',first_price='"+d_data.getString("first_price")+"', coach_reserved_seats='"+(Integer.parseInt(d_data.getString("coach_reserved_seats"))+1)+"', bussiness_reserved_seats='"+(Integer.parseInt(d_data.getString("bussiness_reserved_seats")))+"', first_reserved_seats='"+(Integer.parseInt(d_data.getString("first_reserved_seats")))+"' WHERE id='"+this.DepartureId+"'";               
                    }else if(this.DepartureClassSize.equals("Number Bussiness Seat")){
                        query3="UPDATE trains SET train_name='"+d_data.getString("train_name")+"',train_number='"+d_data.getString("train_number")+"',train_route1='"+d_data.getString("train_route1")+"',train_route2='"+d_data.getString("train_route2")+"',departure_time='"+d_data.getString("departure_time")+"',arrival_time='"+d_data.getString("arrival_time")+"',departure_date='"+d_data.getString("departure_date")+"',arrival_date='"+d_data.getString("arrival_date")+"',coach_class='"+(Integer.parseInt(d_data.getString("coach_class")))+"',bussiness_class='"+(Integer.parseInt(d_data.getString("bussiness_class"))-1)+"',first_class='"+(Integer.parseInt(d_data.getString("first_class")))+"',coach_price='"+d_data.getString("coach_price")+"',bussiness_price='"+d_data.getString("bussiness_price")+"',first_price='"+d_data.getString("first_price")+"', coach_reserved_seats='"+(Integer.parseInt(d_data.getString("coach_reserved_seats")))+"', bussiness_reserved_seats='"+(Integer.parseInt(d_data.getString("bussiness_reserved_seats"))+1)+"', first_reserved_seats='"+(Integer.parseInt(d_data.getString("first_reserved_seats")))+"' WHERE id='"+this.DepartureId+"'";               
                    }else if(this.DepartureClassSize.equals("Number First Seat")){
                        query3="UPDATE trains SET train_name='"+d_data.getString("train_name")+"',train_number='"+d_data.getString("train_number")+"',train_route1='"+d_data.getString("train_route1")+"',train_route2='"+d_data.getString("train_route2")+"',departure_time='"+d_data.getString("departure_time")+"',arrival_time='"+d_data.getString("arrival_time")+"',departure_date='"+d_data.getString("departure_date")+"',arrival_date='"+d_data.getString("arrival_date")+"',coach_class='"+(Integer.parseInt(d_data.getString("coach_class")))+"',bussiness_class='"+(Integer.parseInt(d_data.getString("bussiness_class")))+"',first_class='"+(Integer.parseInt(d_data.getString("first_class"))-1)+"',coach_price='"+d_data.getString("coach_price")+"',bussiness_price='"+d_data.getString("bussiness_price")+"',first_price='"+d_data.getString("first_price")+"', coach_reserved_seats='"+(Integer.parseInt(d_data.getString("coach_reserved_seats")))+"', bussiness_reserved_seats='"+(Integer.parseInt(d_data.getString("bussiness_reserved_seats")))+"', first_reserved_seats='"+(Integer.parseInt(d_data.getString("first_reserved_seats"))+1)+"' WHERE id='"+this.DepartureId+"'";               
                    }
                    
                    db.executeQuery(query3);
                }
            } catch (SQLException ex) {
                Logger.getLogger(Passenger.class.getName()).log(Level.SEVERE, null, ex);
            }
            db.executeQuery(query);
        }
        
        return new FinalFrame(this.FirstName,  this.LastName, this.MiddleName,  this.dob, this.address,  this.passportNumber,
                this.passengerType, this.DepartureId,this.ArrivalId,
                this.roundTrip,randInt(1,15),randInt(1,60),
                this.TicketPrice,this.DepartureClassSize, this.ArrivalClassSize);
    }
        

    @Override
    public ResultSet showInfo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public ResultSet search(){
        String query="SELECT * FROM trains WHERE train_route1='"+route1.getSelectedItem()+"' AND train_route2='"+route2.getSelectedItem()+"' AND departure_date='"+((JTextField)date.getDateEditor().getUiComponent()).getText()+"' AND departure_time BETWEEN '"+time1.getSelectedItem()+"' AND '"+time2.getSelectedItem()+"' ";
        return db.executeSelectQuery(query); 
    }
    public ResultSet searchForArrival(){
        String query="SELECT * FROM trains WHERE train_route1='"+route1.getSelectedItem()+"' AND train_route2='"+route2.getSelectedItem()+"' AND arrival_date='"+((JTextField)date.getDateEditor().getUiComponent()).getText()+"' AND arrival_time BETWEEN '"+time1.getSelectedItem()+"' AND '"+time2.getSelectedItem()+"' ";
        return db.executeSelectQuery(query); 
    }
}
