/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import com.toedter.calendar.JDateChooser;
import java.sql.ResultSet;

/**
 *
 * @author 2016
 */
public class Staff extends RailwayUser{

    public Staff(String FirstName, String LastName, String MiddleName, JDateChooser dob) {
        super(FirstName, LastName, MiddleName, dob);
    }

    @Override
    public ResultSet showInfo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public ResultSet search(){
        return null;
    }
    
}
