package Classes;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2016
 */
public class Ticket implements Railway{
    
    private String ticketId;
    private String firstName;
    private String lastName;
    private String middleName;
    private String dob;
    private String passportNumber;
    private String homeAddress;

    public Ticket(String ticketId, String firstName, String lastName, String middleName, String dob, String passportNumber, String homeAddress) {
        this.ticketId = ticketId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.dob = dob;
        this.passportNumber = passportNumber;
        this.homeAddress = homeAddress;
    }
    
    public Ticket(){}//default

    @Override
    public boolean cancel() {
        return new DataBase().executeQuery("DELETE FROM passenger_info WHERE id='"+this.ticketId+"'");
    }

    @Override
    public boolean update() {
        String query="UPDATE passenger_info SET first_name='"+this.firstName+"', last_name='"+this.lastName+"', middle_name='"+this.middleName+"', dob='"+this.dob+"', passport_number='"+this.passportNumber+"', home_address='"+this.homeAddress+"' WHERE id='"+this.ticketId+"'";
        
        return new DataBase().executeQuery(query);
    }

    @Override
    public boolean search() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
