package Classes;


import com.toedter.calendar.JDateChooser;
import java.sql.ResultSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2016
 */
public abstract class RailwayUser{
    protected String FirstName;
    protected String LastName;
    protected String MiddleName;
    protected JDateChooser dob;

    public RailwayUser(String FirstName, String LastName, String MiddleName, JDateChooser dob) {
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.MiddleName = MiddleName;
        this.dob = dob;
    }
    
    public abstract ResultSet showInfo();
    public ResultSet search(){
        return null;
    }
}
