package Classes;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2016
 */
public class DataBase {
    private String hostname="127.0.0.1";
    private String port="5432";
    private String username="postgres";
    private String password="12345";
    private String dbname="RailwayDB";
    private Connection connect;
    private Statement state;
    private ResultSet pgsql;
    
    public DataBase(){
        try{
        this.connect=DriverManager.getConnection("jdbc:postgresql://"+this.hostname+":"+this.port+"/"+this.dbname,this.username,this.password);
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
    public DataBase (String host,String port, String db, String user, String pass){
        this.hostname=host;
        this.port=port;
        this.dbname=db;
        this.username=user;
        this.password=pass;
        
        try{
        connect=DriverManager.getConnection("jdbc:postgresql://"+this.hostname+":"+this.port+"/"+this.dbname,this.username,this.password);
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
    }
    public boolean checkAuthentication(String uname, String pword){
        try{
            state=this.connect.createStatement();
            pgsql = state.executeQuery("SELECT * FROM administrators;");
            while(pgsql.next()){
                //System.out.printf("%s %s %d\n",pgsql.getString("username"), pgsql.getString("password"),pgsql.getInt("id"));
                
                if(pgsql.getString("username").equals(uname) && pword.equals(pgsql.getString("password"))){
                    return true;
                }
            }
        }
        catch(Exception ex){
            ex.printStackTrace();
        }        
        return false;
    }
    
    public boolean executeQuery(String query){
        try{
            state=this.connect.createStatement();
            state.execute(query);
        }
        catch(Exception ex){
           // System.out.println("DataBase.executeQuery()"+ex);
            
            return false;
        }        
        return true;
    }
    public ResultSet executeSelectQuery(String query){
        try{
            state=this.connect.createStatement();
            pgsql=state.executeQuery(query);
        }
        catch(Exception ex){
           // System.out.println("DataBase.executeQuery()"+ex);
            ex.printStackTrace();
        }
        return pgsql;
    }
    public ResultSet search(String TrainName, String TrainRoute1,
            String Trainroute2,  String DepartureDate,String ArrivalData,JCheckBox SearchByTrainName,JCheckBox SearchByRoutes,  JCheckBox SearchByDate )
    {
        String query="";
        if(SearchByTrainName.isSelected()&&!SearchByRoutes.isSelected()&&!SearchByDate.isSelected())
        {
             query="SELECT * FROM trains WHERE train_name='"+TrainName+"';";
        }else if(SearchByRoutes.isSelected()&&!SearchByTrainName.isSelected()&&!SearchByDate.isSelected()){
             query="SELECT * FROM trains WHERE train_route1='"+TrainRoute1+"' AND train_route2='"+Trainroute2+"';";
        }else if(SearchByDate.isSelected()&&!SearchByTrainName.isSelected()&&!SearchByRoutes.isSelected())
        {
             query="SELECT * FROM trains WHERE departure_date='"+DepartureDate+"' AND arrival_date='"+ArrivalData+"';";
        }else if(SearchByTrainName.isSelected()&&SearchByRoutes.isSelected())
        {
           query="SELECT * FROM trains WHERE train_name='"+TrainName+"'AND train_route1='"+TrainRoute1+"' AND train_route2='"+Trainroute2+"' ;"; 
        }else if(SearchByTrainName.isSelected()&&SearchByDate.isSelected())
        {
            query="SELECT * FROM trains WHERE train_name='"+TrainName+"' AND departure_date='"+DepartureDate+"' AND arrival_date='"+ArrivalData+"' ;";
        }else if (SearchByTrainName.isSelected()&&SearchByRoutes.isSelected()&&SearchByDate.isSelected())
        {
         query="SELECT * FROM trains WHERE train_name='"+TrainName+"'AND train_route1='"+TrainRoute1+"' AND train_route2='"+Trainroute2+"' AND departure_date='"+DepartureDate+"' AND arrival_date='"+ArrivalData+"' ;";    
        }else if(SearchByRoutes.isSelected()&&SearchByDate.isSelected())
        {
            query="SELECT * FROM trains WHERE train_name='"+TrainName+"' AND departure_date='"+DepartureDate+"' AND arrival_date='"+ArrivalData+"';";
        }
        
        
        return this.executeSelectQuery(query);
    }
    
    public boolean isQueryResultEmpty(ResultSet results)
    {
        int count = 0;
        try {
            //display results
            while (results.next()) {
                String data="";
                try {
                    data = results.getString("id");
                } catch (SQLException ex) {
                    Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
                }
                //name.setText(data);
                count++;
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (count < 1) {
          // Didn't even read one row
          return false;
        }else{
            return true;
        }
    }
    
}


