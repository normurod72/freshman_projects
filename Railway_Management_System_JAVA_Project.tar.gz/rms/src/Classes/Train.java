package Classes;


import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import javax.swing.JTextField;
import lu.tudor.santec.jtimechooser.JTimeChooser;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2016
 */
abstract class Train 
{
    protected final JTextField TrainName;
    protected final JTextField TrainId;
    protected final JComboBox TrainRoute1;
    protected final JComboBox TrainRoute2;
    protected final JTimeChooser DepartureTime;
    protected final JTimeChooser ArrivalTime;
    protected final JDateChooser DepartureDate;
    protected final JDateChooser ArrivalDate;
    protected final JTextField CoachClassNumberOfSeats;
    protected final JTextField BussinessClassNumberOfSeats;
    protected final JTextField FirstClassNumberOfSeats;
    protected final JTextField BussinessClassTicketPrice;
    protected final JTextField CoachClassTicketPrice;
    protected final JTextField FirstClassTicketPrice;
    protected final DataBase database=new DataBase();

    Train(JTextField TrainName, JTextField TrainId, JComboBox TrainRoute1, JComboBox TrainRoute2, JTimeChooser DepartureTime, JTimeChooser ArrivalTime, JDateChooser DepartureDate, JDateChooser ArrivalDate,
            JTextField CoachClassNumberOfSeats, JTextField BussinessClassNumberOfSeats, JTextField FirstClassNumberOfSeats, JTextField BussinessClassTicketPrice, 
            JTextField CoachClassTicketPrice, JTextField FirstClassTicketPrice) 
    {
        this.TrainName = TrainName;
        this.TrainId = TrainId;
        this.TrainRoute1 = TrainRoute1;
        this.TrainRoute2 = TrainRoute2;
        this.DepartureTime = DepartureTime;
        this.ArrivalTime = ArrivalTime;
        this.DepartureDate = DepartureDate;
        this.ArrivalDate = ArrivalDate;
        this.CoachClassNumberOfSeats = CoachClassNumberOfSeats;
        this.BussinessClassNumberOfSeats = BussinessClassNumberOfSeats;
        this.FirstClassNumberOfSeats = FirstClassNumberOfSeats;
        this.BussinessClassTicketPrice = BussinessClassTicketPrice;
        this.CoachClassTicketPrice = CoachClassTicketPrice;
        this.FirstClassTicketPrice = FirstClassTicketPrice;
    }
    
    public abstract boolean addTrain();
    public boolean validate()
    {
        
        try
        {
        if(TrainName.getText().equals("")||TrainId.getText().equals("")||CoachClassNumberOfSeats.getText().equals("")||BussinessClassNumberOfSeats.getText().equals("")
                ||FirstClassNumberOfSeats.getText().equals("")||CoachClassTicketPrice.getText().equals("")||BussinessClassTicketPrice.getText().equals("")||FirstClassTicketPrice.getText().equals(""))
                {
                  throw new IllegalStateException();
                }
        else
            {
                if(this.TrainRoute1.getSelectedItem().equals(TrainRoute2.getSelectedItem()))
                {
                    TrainRoute1.setBackground(Color.red);
                    TrainRoute2.setBackground(Color.red);
                    new NotificationMessages().showMismatchErrors("Train routs");
                }
                else
                {     
                    return true;
                }
            }
        }
        catch(Exception c)
        {
            new NotificationMessages().showEmptyFieldsError();
        }
        return false;
    }    

}
