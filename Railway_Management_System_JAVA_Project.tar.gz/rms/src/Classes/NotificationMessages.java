package Classes;


import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2016
 */
public class NotificationMessages{
    
    public void showEmptyFieldsError(){
        JOptionPane.showMessageDialog(null, "Please fill out all the fields!", "Error", JOptionPane.WARNING_MESSAGE);
    }
    public void showMismatchErrors(String msg){
        JOptionPane.showMessageDialog(null, "Please fill the "+msg+" correctly!", "Error", JOptionPane.ERROR_MESSAGE);
    }
    public void ShowSameInformationErrors()
    {
        JOptionPane.showMessageDialog(null, "You entered same information!", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
