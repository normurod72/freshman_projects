package Classes;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.toedter.calendar.JDateChooser;
import java.sql.Time;
import java.text.DateFormat;
import java.util.Date;
import java.util.Calendar;
import lu.tudor.santec.jtimechooser.JTimeChooser;
/**
 *
 * @author 2016
 */
public class FormattedDate {
    
    private Date date;
    private Time time;
    private int year;
    private int month;
    private int day;
    private int hour;
    private int minute;
    private int second;
    
    public FormattedDate(JDateChooser date){
        try{
            this.date=date.getDate();
            Calendar cal = Calendar.getInstance();
            cal.setTime(this.date);
            this.year = cal.get(Calendar.YEAR);
            this.month = cal.get(Calendar.MONTH)+1;
            this.day = cal.get(Calendar.DAY_OF_MONTH);
        }catch(Exception ex){
            new NotificationMessages().showEmptyFieldsError();
        }
    }
    public FormattedDate(){}
    
    public String getCurrentDate(){
        try{
            this.date=new Date();
            Calendar cal = Calendar.getInstance();
            cal.setTime(this.date);
            this.year = cal.get(Calendar.YEAR);
            this.month = cal.get(Calendar.MONTH)+1;
            this.day = cal.get(Calendar.DAY_OF_MONTH);
        }catch(Exception ex){
            new NotificationMessages().showEmptyFieldsError();
        }
        return String.format("%02d.%02d.%04d",this.day,this.month, this.year);
    }
    
    public String getFormattedDate(){
        return String.format("%02d.%02d.%04d",this.day,this.month, this.year);
    }
    public JDateChooser getAsDateFormat(String string_date){
        this.year=Integer.parseInt(string_date.substring(0, 3));
        this.month=Integer.parseInt(string_date.substring(5, 6));
        this.day=Integer.parseInt(string_date.substring(8, 9));
        
        date.setDate(this.day);
        date.setMonth(this.month);
        date.setYear(this.year);
        JDateChooser newDate=new JDateChooser();
        newDate.setDate(date);
        return newDate;
    }
    public JTimeChooser getAsTimeFormat(String string_time){
        this.hour=Integer.parseInt(string_time.substring(0, 1));
        this.minute=Integer.parseInt(string_time.substring(3, 4));
        this.second=Integer.parseInt(string_time.substring(6, 7));
        time.setHours(this.hour);
        time.setMinutes(this.minute);
        time.setSeconds(this.second);
        JTimeChooser newTime=new JTimeChooser();
        newTime.setTime(time);
        return newTime;
    }
}
