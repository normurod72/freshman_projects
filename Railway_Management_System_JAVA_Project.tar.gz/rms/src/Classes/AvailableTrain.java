package Classes;


import com.toedter.calendar.JDateChooser;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import lu.tudor.santec.jtimechooser.JTimeChooser;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 2016
 */
public class AvailableTrain extends Train{

    public AvailableTrain(JTextField TrainName, JTextField TrainId, JComboBox<String> TrainRoute1, JComboBox<String> TrainRoute2, 
            JTimeChooser DepartureTime, JTimeChooser ArrivalTime, JDateChooser DepartureDate, JDateChooser ArrivalDate, 
            JTextField CoachClassNumberOfSeats, JTextField BussinessClassNumberOfSeats, JTextField FirstClassNumberOfSeats, 
            JTextField BussinessTicketPrice, JTextField CoachTicketPrice, JTextField FirstClassTicketPrice) {
        super(TrainName,TrainId,TrainRoute1,TrainRoute2,DepartureTime,ArrivalTime,DepartureDate,ArrivalDate,
                CoachClassNumberOfSeats,BussinessClassNumberOfSeats,FirstClassNumberOfSeats,BussinessTicketPrice,
                CoachTicketPrice,FirstClassTicketPrice);
    }
    public AvailableTrain(){
        super(null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    }
    
    @Override
    public boolean addTrain()
    {

        String query="INSERT INTO trains (train_name,train_number,train_route1,train_route2,departure_time,arrival_time,departure_date,arrival_date,"
                + "coach_class,bussiness_class,first_class,coach_price,bussiness_price,first_price) VALUES('"+this.TrainName.getText()+"',"
                + "'"+this.TrainId.getText()+"','"+this.TrainRoute1.getSelectedItem()+"','"+this.TrainRoute2.getSelectedItem()+"',"
                + "'"+this.DepartureTime.getFormatedTime()+"','"+this.ArrivalTime.getFormatedTime()+"','"+new FormattedDate(this.DepartureDate).getFormattedDate()+"',"
                + "'"+new FormattedDate(this.ArrivalDate).getFormattedDate()+"',"+this.CoachClassNumberOfSeats.getText()+","+this.BussinessClassNumberOfSeats.getText()+","
                + ""+this.FirstClassNumberOfSeats.getText()+","+this.CoachClassTicketPrice.getText()+","+this.BussinessClassTicketPrice.getText()+","
                + ""+this.FirstClassTicketPrice.getText()+")";
        
        try{
            return database.executeQuery(query);
        }catch(Exception c){
            
            JOptionPane.showMessageDialog(null, c);
        }
        
        return true;
    }
   
    public boolean deleteTrain(String TrainName, String TrainID,String TrainRoute1,
            String Trainroute2,  String DepartureTime,String ArrivalTime,String DepartureDate,String ArrivalDate,String coach,String bussiness,String first,String coach_price,String bussiness_price,String first_price){
        String query="DELETE FROM trains WHERE train_name='"+TrainName+"' AND train_number='"+TrainID+"' AND train_route1='"+TrainRoute1+"' AND train_route2='"+Trainroute2+"' AND departure_date='"+DepartureDate+"' AND arrival_date='"+ArrivalDate+"'" ;
        String add_query="INSERT INTO deleted_trains (train_name,train_number,train_route1,train_route2,departure_time,arrival_time,departure_date,arrival_date,"
                + "coach_class,bussiness_class,first_class,coach_price,bussiness_price,first_price) VALUES('"+TrainName+"',"
                + "'"+TrainID+"','"+TrainRoute1+"','"+Trainroute2+"',"
                + "'"+DepartureTime+"','"+ArrivalTime+"','"+DepartureDate+"',"
                + "'"+ArrivalDate+"',"+coach+","+bussiness+","
                + ""+first+","+coach_price+","+bussiness_price+","
                + ""+first_price+")";
        
        try{
            database.executeQuery(add_query);
            return database.executeQuery(query);
        }catch(Exception c){
            JOptionPane.showMessageDialog(null, c);
        }
        
        return true;
    }
   
    
    public boolean EditTrain(String ID,String TrainName, String TrainID,String TrainRoute1,
            String Trainroute2,  String DepartureTime,String ArrivalTime,String DepartureDate,String ArrivalDate,String coach,String bussiness,String first,String coach_price,String bussiness_price,String first_price){
        String query="UPDATE trains SET train_name='"+TrainName+"', train_number='"+TrainID+"', train_route1='"+TrainRoute1+"', train_route2='"+Trainroute2+"',departure_time='"+DepartureTime+"',arrival_time='"+ArrivalTime+"', departure_date='"+DepartureDate+"', arrival_date='"+ArrivalDate+"', coach_class='"+coach+"', bussiness_class='"+bussiness+"', first_class='"+first+"', coach_price='"+coach_price+"', bussiness_price='"+bussiness_price+"', first_price='"+first_price+"' WHERE id="+ID+";";
        
        
        try{
            
            return database.executeQuery(query);
        }catch(Exception c){
            
            JOptionPane.showMessageDialog(null, c);
        }
        
        return true;
    
        
    }


    
}
