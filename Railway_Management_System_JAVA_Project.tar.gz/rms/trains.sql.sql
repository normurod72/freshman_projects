DELETE FROM trains WHERE train_name='Nodir' AND train_number='normurod' AND train_route1='Andijon' AND train_route2='Tashkent' AND departure_date='2016-12-31' AND arrival_date='2016-12-30';
