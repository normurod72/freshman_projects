	====================  Inha University in Tashkent  ====================
	====================  JAVA PROJECT FOR FINAL  =========================

	## ID:	U1510340
	## Group: 001
	## Name: Normurod Mamasoliev

	** Minimum requirements to this project source **
	# Netbeans IDE 8.1
	# PostgreSQL 9.4
	# JDatePicker.jar from github.com
	# JDatePicker.jar from github.com

	/*
	 ***************************************
	 Once you unzip the source you source
	 you should import the train.sql.sql
	 to your pgSQL using pgAdmin or Postgre 
	 Maestro workbench.
	  After setting up db files make sure
	 to configure database.java inside classes
	 folder. You cannot buid this source code
	 NetBean IDE's below the version 8.1
	****************************************
					       */


	RAILWAY MANAGEMANET SYSTEM

	=========================================================================

	* * * * * * *	        ***         **	        * * * * * * * 
	* * * * * * * *        ** **       ****	       * * * * * * * * *
	* *         * *	      **   **     **  **       * *
	* *         * *      **	    **   **    **      * * 
	* * * * * * * *	    **	     *****      **     * * * * * * * * *
	* * * * * * * *    **	      ***	 **		     * *
	* *         * *	  **			  **    	     * *
	* *         * *	 **			   **  * * * * * * * * *
	* *         * *	**			    **  * * * * * * * 

	=========================================================================


















