#ifndef MEMBER_H
#define MEMBER_H

#include "UserInterface.h"
#include <fstream>

class Member
{
public:
	Member();
	virtual void createMembership()=0;//for seller and admin
	virtual void showOptions()=0;//for all derived classes
	int Admin_permission(string, string);
	int Seller_permission(string, string);
	int Customer_permission(string, string);
	void setDefaults();
	bool check_defaults();
	friend void Main_menu(int);
protected:
	UserInterface menu;
	string username;
	string password;
};

#endif //!MEMBER_H