#include "E_Book.h"
#include <iomanip>

E_Book::E_Book(string b, string a, string i, int v, string c, int q, float p,float s):
	Book(b,a,i,v,c,q,p,1),filesize(s){}

int E_Book::showEbooks()
{
	string cName, bName, aName, ISBN;
	int vNumber; float cost, filesize;
	system("cls");
	int i = 16;
	cout << setw(i) << "Category" << setw(i) << "Name" << setw(i) << "Author" << setw(i) << "FileSize" << setw(i - 5) << "Price" << endl;
	cout << setw(i) << "--------" << setw(i) << "----" << setw(i) << "------" << setw(i) << "--------" << setw(i - 5) << "-----" << endl;

	ifstream getfile("e-book", ios::in);
	while (!getfile.eof()) {
		getfile >> cName >> bName >> aName >> ISBN >> vNumber >> filesize >> cost;
		if (!getfile.eof()) {
			cout << setw(i) << cName << setw(i) << bName << setw(i) << aName << setw(i)
				<< filesize << setw(i - 5) << cost << " $" << endl;
		}

	}
	getfile.close();
	/*do {
		cout << "\t\t\tPress ESC to go back\n";
		int suggestions = _getch();
		if (suggestions == 27) {
			Seller obj;
			obj.showOptions();
		}
		else {
			cout << "Press correct key!";
		}
	} while (1);
	*/
	return 0;
}

int E_Book::addE_Book()
{
	ofstream addData("e-book", ios::app);
	addData << categoryName << " " << bookName << " " << AuthorName << " " << ISBN << " " << versionNumber << " "
		<<filesize << " " << cost << " " << endl;
	addData.close();
	system("cls");cout << "\n\n\n\n\n\n\t\t\t\tNew E-book succesfully added";
	Sleep(1200);
	system("cls");
	return 1;
}
