#ifndef BOOK_H
#define BOOK_H

#include <string>
#include "Seller.h"

using namespace std;

class Book
{
public:
	Book(string, string, string, int, string, int, float, bool);
	int addBook();
	void showBooksInfo(string, string);
private:
	const int quantity;
	bool original;
protected:
	const string bookName;
	const string AuthorName;
	const float cost;
	const string ISBN;
	const string categoryName;
	const int versionNumber;
};

#endif// ! BOOK_h
