#include "Book.h"
#include <iomanip>


Book::Book(string bname, string author, string isbn,int vnumb, string category, int quant, float price, bool org):
	bookName(bname),AuthorName(author),ISBN(isbn),versionNumber(vnumb),categoryName(category),
	quantity(quant),cost(price),original(org){}

void Book::showBooksInfo(string dbname, string n) {
	string cName, bName, aName, ISBN;
	int vNumber, quant; float cost;bool org;
	system("cls");
	int i = 16;
	cout << setw(i) << "Category" << setw(i) << "Name" << setw(i) << "Author" << setw(i) << "Quantity" << setw(i - 5) << "Price" << endl;
	cout << setw(i) << "--------" << setw(i) << "----" << setw(i) << "------" << setw(i) << "--------" << setw(i - 5) << "-----" << endl;

	ifstream getfile(dbname, ios::in);
	while (!getfile.eof()) {
		getfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
		if (!getfile.eof()) {
			cout << setw(i) << cName << setw(i) << bName << setw(i) << aName << setw(i)
				<< quant << setw(i - 5) << cost << " $" << endl;
		}

	}
	getfile.close();
	cout << "\n\n\t\t\tPress ENTER to select book\n";
	cout << "\t\t\tPress ESC to go back\n";
	int suggestions = _getch();
	string bvalue;
	if (suggestions == 13) {
		cout << "Enter the name of book: ";
		cin >> bvalue;
//		search_for("book", bvalue);
	}
	else if (suggestions == 27) {
		system("cls");
		//use.showOptions();
	}
	else {

	}
}

int Book::addBook()
{
	ofstream addData("book", ios::app);
	addData << categoryName << " " << bookName << " " << AuthorName << " " << ISBN << " " << versionNumber << " "
		<< quantity << " " << cost << " " << original << endl;
	addData.close();
	system("cls");cout << "\n\n\n\n\n\n\t\t\t\tNew book succesfully added";
	Sleep(1200);
		system("cls");
		return 1;
}
