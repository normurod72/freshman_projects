#include "Member.h"

Member::Member() :menu("litblue", "blue"){}

int Member::Admin_permission(string uname, string pword) {
	ifstream file("admin.dat");
	string u, p;
	file >> u >> p;
	if (u == uname&&pword == p) {
		return 1;
	}
	else {
		return 2;
	}
}

int Member::Seller_permission(string uname, string pword)
{
	ifstream file("seller.dat");
	string u, p;
	file >> u >> p;
	if (u == uname&&pword == p) {
		return 1;
	}
	else {
		return 2;
	}
}

int Member::Customer_permission(string uname, string password)
{
	ifstream file("customers.dat");
	string u, p, ar[4];
	while (!file.eof()) {
		file >> u >> p >> ar[0] >> ar[1] >> ar[2]>>ar[3];
		if (u == uname&&password == p) {
			return 1;
		}		
	}
	return 2;
}

void Member::setDefaults()
{
	ofstream("book", ios::app);
	ofstream("shop", ios::app);
}

bool Member::check_defaults() {
	ifstream file("admin.dat");
	ifstream file2("seller.dat");
	ifstream file3("book");
	ifstream file4("shop");
	if (!file || !file2 || !file3 || !file4) {
		return false;
	}
	else {
		return true;
	}
}