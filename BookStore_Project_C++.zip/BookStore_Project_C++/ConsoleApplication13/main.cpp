/* * * * * * * * * * * * * * * * * * * * * * * * *  * 
 *   Project-BOOKSTORE								*
 * * * * * * * * * * * * * * * * * * * * * * * * * */


#include <iostream>
#include <string>
#include <vector>
#include "Member.h"
#include "Admin.h"
#include "Customer.h"
#include "Seller.h"

using namespace std;

void Main_menu(int inpt) {
	vector<string> main_menu_options = { "Customer's area","Seller's area","For shop owner","Exit" };
	vector<string> admin_options = { "Set new  Seller","Check cash","Return to Main menu" };
	vector<string> seller_options = {"Search books","Insert new book","Insert new E-book","Show all existing books","Return main menu"};
	vector<string> customer_options = { "See books","Search book","E-Books","Create membership","Return main menu" };
//----------------------------------------------------------------------------------seller_options.insert(seller_options.end() - 1, "Hello");
//----------------------------------------------------------------------------------
		Member *create; 
		create = new Admin(admin_options);
		create->setDefaults();
	if(!create->check_defaults())
		{
			create->createMembership();
		}
	else 
		{
			int choice_number;
			choice_number = create->menu.showChoiceMenu(inpt,main_menu_options);
			system("cls");
			if (choice_number == 2) {
				int mode;
				do {
					string u, p;
					int j;
					system("cls");
					cout << "\n\n\n\n\t\t\t"; create->menu.gcout("Username:", "litblue");
					cin >> u;
					cout << "\n\t\t\t"; create->menu.gcout("Password:", "litblue");
					cin >> p;
						create = new Seller(seller_options);
					mode = create->Seller_permission(u, p);
					if (mode == 1) {
						system("cls");
						create->showOptions();
					}
					else {
						cout << "\n\n\t\t";create->menu.gcout("Wrong!", "yellow");
						cout << "\n\t\t"; create->menu.gcout("Press ENTER to continue or ESC to go back <<", "yellow");
						j = _getch();
						if (j == 27) {
							system("cls");
							Main_menu(1);
							break;

						}
					}
					system("cls");
				} while (mode != 1);
			}
			else if (choice_number == 1) {
				create = new Customer(customer_options);
				create->showOptions();
			}
			else if (choice_number == 3) {
					int a;
					do {
						string u, p;
						int j;
						system("cls");
						cout << "\n\n\n\n\t\t\t"; create->menu.gcout("Username:", "litblue");
						cin >> u;
						cout << "\n\t\t\t"; create->menu.gcout("Password:", "litblue");
						cin >> p;
						a = create->Admin_permission(u, p);
						if (a == 1) {
							system("cls");
							create->showOptions();
						}
						else {
							cout << "\n\n\t\t";create->menu.gcout("Wrong!","yellow");
							cout << "\n\t\t"; create->menu.gcout("Press ENTER to continue or ESC to go back <<", "yellow");
							j = _getch();
							if (j == 27) {
								system("cls");
								Main_menu(2);
								break;
							}
						}
						system("cls");
					} while (a != 1);

				}
			else if(choice_number=main_menu_options.size()-1) {
			cout << "\n\n\n\n\n\n\n\n\t\t\tThank you for using this App!!!\n";
			Sleep(1000);
		}
		}
}

void main() {
	
	Main_menu(0);
	
}