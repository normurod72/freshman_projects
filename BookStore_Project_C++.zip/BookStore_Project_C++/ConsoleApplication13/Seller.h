#pragma once
#ifndef SELLER_H
#define SELLER_H

#include "Member.h"
#include "Admin.h"
#include "UserInterface.h"
#include "Customer.h"

class Seller:public Member{
public:
	Seller(vector<string>&);
	Seller();
	void createMembership();
	string showPayOptions();
	void showOptions();
	int search_for(string);
	void setNewBook();
	void setNewE_Book();
	int ShowCheck(string,int&, float&);
private:
	void deleteBook(string&,int&,int&);
	const vector<string> payOpts = {"Pay by money","Pay by Credit card"};
	vector<string> seller_options;	
};

#endif //! SELLER_H