#include "Admin.h"
#include "Seller.h"

Seller obj;

Admin::Admin(vector<string> &ao):options(ao){}

Admin::Admin(){}

void Admin::showOptions() {
	cout << "\t\tIf you are not Administrator please go back!";
	int res = menu.showChoiceMenu(0,options);
	if (res == 1) {
		changeSellerInfo();
	}
	else if (res == 2) {
		system("cls");
		checkCash();
	}
	else if (res == options.size()) {
		system("cls");
		Main_menu(2);
	}
}

void Admin::checkCash()
{
	string ar[2];
	int q;
	double cash;double shop_cash=0;
	ifstream file("shop", ios::in);
	while (!file.eof()) {
		file >> ar[0] >> q >> cash;
		if (!file.eof()) {
			shop_cash += q*cash;
		}
	}
	file.close();
	system("cls");
	cout << "\n\n\n\n\n\t\t\t\tCurrent cash is: " << shop_cash<<" $";
	cash=menu.suggestExit();
	if (cash==8) {
		system("cls");
		showOptions();
	}
	else {
		system("cls");
		Main_menu(2);
	}
}

void Admin::createMembership() {

	string name, surname, dob, username, password;//these are temporary variables only for the first time users
	int age;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n","litblue");
	cout << endl << endl; menu.gcout("\tEnter your name: ", "litblue");
	cin >> name;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl<<endl; menu.gcout("\tEnter your surname: ","litblue");
	cin >> surname;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tEnter your age: ", "litblue");
	cin >> age;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tEnter your date of birth(dd.mm.yy): ", "litblue");
	cin >> dob;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tEnter username: ", "green");
	cin >> username;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tUsername: ", "green"); cout << username;
	cout << endl << endl; menu.gcout("\tEnter password: ", "green");
	cin >> password;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tUsername: ", "green"); cout << username;
	cout << endl << endl; menu.gcout("\tPassword: ", "green"); cout << password;
	cout << endl << endl;
	cout << "\t\t Please choose the following options" << endl;
	cout << "\n\t\tPress ENTER - to submit data";
	cout << "\n\t\tPress BACKSPACE - to reset data";
	cout << "\n\t\tPress ESC - to exit";
	int q;
	do {
		q = 0;
		int c = _getch();
		if (c == 13) {
			ofstream adm("admin.dat");
			adm << username << " " << password << " " << age << " " << dob << " " << name << " " << surname << endl;
			adm.close();
			system("cls");
			cout << "\n\n\n\n\t\tYour data successfully submitted!";
			system("cls");
			
			obj.createMembership();
		}
		else if (c == 8) {
			this->createMembership();
		}
		else if (c == 27) {
			system("cls");
			Main_menu(2);
		}
		else {
			cout << endl << "Use appropriate keys";
			q = 1;
		}
	} while (q==1);
	
}

void Admin::changeSellerInfo()
{
	obj.createMembership();
}
