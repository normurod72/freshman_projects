#pragma once
#ifndef ADMIN_H
#define ADMIN_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "Member.h"

using namespace std;

class Admin:public Member{
public:
	Admin(vector<string>&);
	Admin();
	void showOptions();
	void checkCash();
	void createMembership();
	void changeSellerInfo();

private:
	vector<string> options;
};

#endif //!ADMIN_H