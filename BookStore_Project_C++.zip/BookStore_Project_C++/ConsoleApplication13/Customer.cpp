#include "Customer.h"
#include <iomanip>
#include "E_Book.h"

Customer::Customer(vector<string>& co):customer_opts(co){}

Customer::Customer(){}

void Customer::createMembership() {
	string name, surname, dob, username, password;
	int age;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- Customer Registration ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tEnter your name: ", "litblue");
	cin >> name;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- Customer Registration ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tEnter your surname: ", "litblue");
	cin >> surname;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- Customer Registration ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tEnter your age: ", "litblue");
	cin >> age;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- Customer Registration ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tEnter your date of birth(dd.mm.yy): ", "litblue");
	cin >> dob;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- Customer Registration ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tEnter username: ", "green");
	cin >> username;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- Customer Registration ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tUsername: ", "green"); cout << username;
	cout << endl << endl; menu.gcout("\tEnter password: ", "green");
	cin >> password;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- Customer Registration ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tUsername: ", "green"); cout << username;
	cout << endl << endl; menu.gcout("\tPassword: ", "green"); cout << password;
	cout << endl << endl;
	cout << "\t\t Please choose the following options" << endl;
	cout << "\n\t\tPress ENTER - to submit data";
	cout << "\n\t\tPress BACKSPACE - to reset data";
	cout << "\n\t\tPress ESC - to exit";
	int q;
	do {
		q = 0;
		int c = _getch();
		if (c == 13) {
			ofstream adm("customers.dat",ios::app);
			adm << username << " " << password << " " << age << " " << dob << " " << name << " " << surname << endl;
			adm.close();
			system("cls");
			cout << "\n\n\n\n\t\tYour data successfully submitted!";
			Sleep(1500);
			showOptions();
		}
		else if (c == 8) {
			this->createMembership();
		}
		else if (c == 27) {
			system("cls");
			Main_menu(2);
		}
		else {
			cout << endl << "Use appropriate keys";
			q = 1;
		}
	} while (q == 1);
}

void Customer::showOptions() {
	int return_value=menu.showChoiceMenu(0,customer_opts);
	if (return_value == customer_opts.size()) {
		system("cls");
		Main_menu(0);
	}
	else if (return_value == 1) {
		seeBooks();
	}
	else if (return_value == 2) {
		string value;
		system("cls");
		cout << "\n\n\n\n\n\t\t\t";
		menu.gcout("Enter the name of book: ", "litblue");
		cin >> value;
		Seller obj;
		if (obj.search_for(value) == 1) {
			system("cls");
			showOptions();
		}
	}
	else if (return_value == 3) {

		//E_Book object;
		//object.showEbooks();
	}
	else if (return_value == 4) {
		system("cls");
		int z=menu.showChoiceMenu(0, { "Become a member","Enter account","Go back" });
		if (z==1) {
			createMembership();
		}
		else if(z==2) {
			int mode;
			do {
				string u, p;
				int j;
				system("cls");
				cout << "\n\n\n\n\t\t\t"; menu.gcout("Username:", "litblue");
				cin >> u;
				cout << "\n\t\t\t"; menu.gcout("Password:", "litblue");
				cin >> p;
				mode = Customer_permission(u, p);
				if (mode == 1) {
					system("cls");
					if(customer_opts.size()<6)
					customer_opts.insert(customer_opts.end() - 1, "Take for rent");
					showOptions();
				}
				else {
					cout << "\n\n\t\t";menu.gcout("Wrong!", "yellow");
					cout << "\n\t\t"; menu.gcout("Press ENTER to continue or ESC to go back <<", "yellow");
					j = _getch();
					if (j == 27) {
						system("cls");
						showOptions();
						break;

					}
				}
				system("cls");
			} while (mode != 1);
		}
		else if (z == 3) {
			system("cls");
			showOptions();
		}
	}
	else if (return_value == 5) {
		string value;
		system("cls");
		cout << "\n\n\n\n\n\t\t\t";
		menu.gcout("Enter the name of book: ", "litblue");
		cin >> value;
		takeForRent(value);
	}
}

void Customer::takeForRent(string inpt) {
	string cName, bName, aName, ISBN;
	int vNumber, quant; float cost;bool org;
	system("cls");
	int i = 16;
	cout << setw(i); menu.gcout("Category", "green"); cout << setw(i); menu.gcout("Name", "green"); cout << setw(i);
	menu.gcout("Author", "green"); cout << setw(i); menu.gcout("Quantity", "green"); cout << setw(i - 5);
	menu.gcout("Price", "green"); cout << endl;
	cout << setw(i) << "--------" << setw(i) << "----" << setw(i) << "------" << setw(i) << "--------" << setw(i - 5) << "-----" << endl;
	int d = 1;
	ifstream getfile("book", ios::in);
	while (!getfile.eof()) {
		getfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
		if (!getfile.eof()) {
			if (inpt == bName) {
				cout << setw(i) << cName << setw(i) << bName << setw(i) << aName << setw(i)
					<< quant << setw(i - 5) << cost << " $" << endl;
				d = 0;
				break;
			}
		}
	}
	getfile.close();

	if (d == 0) {
		bool var = 0;
		do {
			cout << "\n\n\t\t\t";
			menu.gcout("Press ENTER to take book", "litblue");
			cout << "\n\t\t\t";
			menu.gcout("Press ESC to go back\n", "litblue");
			int suggestions = _getch();
			string bvalue;
			if (suggestions == 13) {
				int numbOfBook;
				for (unsigned i = 0; ;) {
					cout << "\n\n\t\t\t";
					menu.gcout("Enter the number of book you want to take", "litblue");
					cin >> numbOfBook;
					if (numbOfBook > quant || numbOfBook <= 0) {
						cout << "\n\nSorry we have got " << quant << " book!";
					}
					else {
						{
							//***********************
							string cName, bName, aName, ISBN;
							int vNumber, quant; float cost;bool org;
							ifstream getfile("book", ios::in);
							ofstream outfile(".arch", ios::out);
							ofstream cashfile("shop", ios::app);
							while (!getfile.eof()) {
								getfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
								if (!getfile.eof()) {
									if (inpt == bName) {
										if (quant > numbOfBook) {
											outfile << cName << " " << bName << " " << aName << " " << ISBN << " " << vNumber << " "
												<< quant - numbOfBook << " " << cost << " " << org << endl;
											cashfile << bName << " " << numbOfBook << " " << cost << endl;
										}
										else {
											cashfile << bName << " " << numbOfBook << " " << cost << endl;
										}
									}
									else {
										outfile << cName << " " << bName << " " << aName << " " << ISBN << " " << vNumber << " "
											<< quant << " " << cost << " " << org << endl;
									}
								}
							}
							cashfile.close();
							outfile.close();
							getfile.close();

							ofstream newFile("book");
							ifstream oldfile(".arch", ios::in);
							while (!oldfile.eof()) {
								oldfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
								if (!oldfile.eof()) {
									newFile << cName << " " << bName << " " << aName << " " << ISBN << " " << vNumber << " "
										<< quant << " " << cost << " " << org << endl;
								}
							}
							oldfile.close();
							newFile.close();

							//***********************
							system("cls");
							cout << "Your took this book for a month free!\n Please bring it back on time!";
							Sleep(1200);
							system("cls");
							showOptions();
						}
						break;
					}
				}
				cout << "\n\n\t\t\t";
				system("cls");
			}
			else if (suggestions == 27) {
				system("cls");
				showOptions();
				break;
			}
			else {
				menu.gcout("\n\nPress correct key!", "yellow");
				var = 1;
			}
		} while (var == 1);
	}
	else {
		if (menu.suggestExit() == 8) {
			system("cls");
			showOptions();
		}
		else {
			exit;
		}
	}
}

void Customer::seeBooks() {
	string cName, bName, aName, ISBN;
	int vNumber, quant; float cost;bool org;
	system("cls");
	int i = 16;
	cout << setw(i); menu.gcout("Category", "green"); cout << setw(i); menu.gcout("Name", "green"); cout << setw(i); 
	menu.gcout("Author", "green"); cout << setw(i); menu.gcout("Quantity", "green"); cout << setw(i - 5);
	menu.gcout("Price", "green"); cout << endl;
	cout << setw(i) << "--------" << setw(i) << "----" << setw(i) << "------" << setw(i) << "--------" << setw(i - 5) << "-----" << endl;

	ifstream getfile("book", ios::in);
	while (!getfile.eof()) {
		getfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
		if (!getfile.eof()) {
			cout << setw(i) << cName << setw(i) << bName << setw(i) << aName << setw(i)
				<< quant << setw(i - 5) << cost << " $" << endl;
		}

	}
	getfile.close();
	bool var = 0;
	do {
		cout << "\n\n\t\t\t";
		menu.gcout("Press ENTER to select book", "litblue");
		cout << "\n\t\t\t";
		menu.gcout("Press ESC to go back\n", "litblue");
		int suggestions = _getch();
		string bvalue;
		if (suggestions == 13) {
			cout << "\n\n\t\t\t";
			menu.gcout("Enter the name of book: ", "litblue");
			cin >> bvalue;
			Seller obj;
			if (obj.search_for(bvalue) == 1) {
				system("cls");
				showOptions();
				break;
			}
		}
		else if (suggestions == 27) {
			system("cls");
			showOptions();
			break;
		}
		else {
			menu.gcout("\n\nPress correct key!", "yellow");
			var = 1;
		}
	} while (var==1);
}

void Customer::buyBook(string &name)
{
	//	Seller object;
	system("cls");
	//	string rvalue=object.showPayOptions();
	/*if (rvalue == "money") {
	ofstream fileout("shop", ios::app);
	fileout << name << " " << quantity << " " << cost<<endl;
	fileout.close();
	}*/
}