#include "UserInterface.h"
#include <iomanip>


UserInterface::UserInterface(string font_color, string color_onfocus)
{
	textColor = font_color;
	onFocusColor = color_onfocus;
}

void UserInterface::gcout(string text, string textcolorname) {
	HANDLE hConsole;
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	int color;
	if (textcolorname == "blue") {
		color = 9;
	}
	else if (textcolorname == "red") {
		color = 12;
	}
	else if (textcolorname == "green") {
		color = 10;
	}
	else if (textcolorname == "yellow") {
		color = 14;
	}
	else if (textcolorname == "white") {
		color = 15;
	}
	else if (textcolorname == "litblue") {
		color = 11;
	}
	else {
		color = 0;
	}
	//1-blue
	//2-green
	//3-lightblue
	//4-red
	//5-pink
	//6-yellow
	//7-grey
	//8-dakrgrey
	//9-extrablue
	//10-extragreen
	//11-exxtralightblue
	//12-extrared
	//13-extrapink
	//14-extrayellow
	//16-blue_background black font
	//228-yellow background red text
	FlushConsoleInputBuffer(hConsole);
	
	SetConsoleTextAttribute(hConsole, color);
	cout << text;
	SetConsoleTextAttribute(hConsole, 15);
}

int UserInterface::showChoiceMenu(int input = 0, vector<string> menuOptions = {"none"}) {
	if (input>=0) {
		cout << endl << endl;
		cout << setw(75)<< "=========================== Bookstore ===========================";
		cout << endl<<endl;
		for (unsigned i = 0; i < menuOptions.size();i++) {

			if (i == input) {
				cout << "\t\t\t  " << ">" << " ";
				gcout(menuOptions[i], onFocusColor);
				cout << endl;
			}
			else {
				cout << "\t\t\t" << "#" << " ";
				gcout(menuOptions[i], textColor);
				cout << endl;
			}
			cout <<endl;
		}
		cout << endl;
		cout << setw(75)<< "=========================== Bookstore ===========================";
	}

	int count = input;
	while (1) {
		input = _getch();
		if (input == 80) {
			if (count != menuOptions.size() - 1) {
				count++;
			}
			else {
				count = 0;
			}

			system("cls");
			cout << endl << endl;
			cout << setw(75) << "=========================== Bookstore ===========================";
			cout << endl << endl;
			for (unsigned i = 0; i < menuOptions.size();i++) {

				if (i == count) {
					cout << "\t\t\t  " << ">" << " ";
					gcout(menuOptions[count], onFocusColor);
					cout << endl;
				}
				else {
					cout << "\t\t\t" << "#" << " ";
					gcout(menuOptions[i], textColor);
					cout << endl;
				}
				cout << endl;
			}
			cout << endl;
			cout << setw(75) << "=========================== Bookstore ===========================";
		}
		else if (input == 72) {
			if (count != 0) {
				count--;
			}
			else {
				count = menuOptions.size() - 1;
			}
			system("cls");
			cout << endl << endl;
			cout << setw(75) << "=========================== Bookstore ===========================";
			cout << endl << endl;
			for (unsigned i = 0; i < menuOptions.size();i++) {

				if (i == count) {
					cout << "\t\t\t  " << ">" << " ";
					gcout(menuOptions[count], onFocusColor);
					cout << endl;
				}
				else {
					cout << "\t\t\t" << "#" << " ";
					gcout(menuOptions[i], textColor);
					cout << endl;
				}
				cout << endl;
			}
			cout << endl;
			cout << setw(75) << "=========================== Bookstore ===========================";
		}
		else if (input == 224) {
			//cout<<"other"<<endl;
		}
		else if (input == 13) {
			return count + 1;
		}
		else {
			gcout("\nPlease use only 'UP' and 'DOWN' keys !!!", "yellow");
			cout << "\n\r\r";
		}
	}
}

int UserInterface::suggestExit() {
	gcout("\n\n\n\tPress ", "litblue"); gcout("BACKSPACE", "green"); gcout("to go back","litblue");
	gcout("\n\tOr press ","litblue"); gcout("ESC","green"); gcout(" to exit! ","litblue");
	int in = _getch();
	if (in == 8 || in == 27) {
		return in;
	}
	else {
		system("cls");
		gcout("\n\n\n\tPress correct key!", "yellow");
		return suggestExit();
	}
}

