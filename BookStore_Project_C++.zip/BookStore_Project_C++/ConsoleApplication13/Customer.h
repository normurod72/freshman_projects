#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "Member.h"
#include "Seller.h"

class Customer:public Member{
public:
	Customer(vector<string>&);
	Customer();
	void createMembership();
	void showOptions();
	void seeBooks();
	void buyBook(string&);
	void takeForRent(string);
private:
	vector<string> customer_opts;
	string name;
	string phoneNumber;
	string email;
	bool gender;
};

#endif // !CUSTOMER_H
