#ifndef USERINTERFACE_H
#define USERINTERFACE_H

#include <iostream>
#include <string>
#include <vector>
#include <Windows.h>
#include <conio.h>

using namespace std;

class UserInterface
{
public:
	UserInterface(string,string);
	int showChoiceMenu(int,vector<string>);
	void gcout(string,string);
	int suggestExit();
private:
	vector<string> menu;
	int inputPosition;
	string textColor;
	string onFocusColor;
};

#endif //!USERINTERFACE_H