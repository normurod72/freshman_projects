#ifndef E_BOOK_H
#define E_BOOK_H

#include "Book.h"

class E_Book:public Book
{
public:
	E_Book(string, string, string, int, string, int, float,float);
	int showEbooks();
	int addE_Book();
private:
	const float filesize;
};

#endif // ! E_BOOK_H