#include "Seller.h"
#include <iomanip>
#include "Book.h"
#include "E_Book.h"
#include <stdexcept>


Seller::Seller(vector<string> &so):seller_options(so){}

Seller::Seller(){}

void Seller::showOptions() {
	int res = menu.showChoiceMenu(0, seller_options);
	if (res == 1) {
		string value;
		system("cls");
		cout << "\n\n\n\n\n\t\t\t";
		menu.gcout("Enter the name of book: ", "litblue");
		cin >> value;
		if (value.size() != 0) {
			string cName, bName, aName, ISBN;
			int vNumber, quant; float cost;bool org;
			system("cls");
			int i = 16;
			cout << setw(i); menu.gcout("Category", "green"); cout << setw(i); menu.gcout("Name", "green"); cout << setw(i);
			menu.gcout("Author", "green"); cout << setw(i); menu.gcout("Quantity", "green"); cout << setw(i - 5);
			menu.gcout("Price", "green"); cout << endl;
			cout << setw(i) << "--------" << setw(i) << "----" << setw(i) << "------" << setw(i) << "--------" << setw(i - 5) << "-----" << endl;

			ifstream getfile("book", ios::in);
			while (!getfile.eof()) {
				getfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
				if (!getfile.eof()) {
					if (value == bName) {
						cout << setw(i) << cName << setw(i) << bName << setw(i) << aName << setw(i)
							<< quant << setw(i - 5) << cost << " $" << endl;break;
					}
				}
			}
			getfile.close();
		}
		else {
			cout << "Enter correct key!";
		}
		do {
			if (menu.suggestExit()==8) {
				system("cls");
				showOptions();
				break;
			}
			else {
				exit;
				break;
			}
		} while (1);
	}
	else if (res==2) {
		setNewBook();
	}
	else if (res == 3) {
		setNewE_Book();
	}
	else if (res == 4) {
		string cName, bName, aName, ISBN;
		int vNumber, quant; float cost;bool org;
		system("cls");
		int i = 16;
		cout << setw(i); menu.gcout("Category", "green"); cout << setw(i); menu.gcout("Name", "green"); cout << setw(i);
		menu.gcout("Author", "green"); cout << setw(i); menu.gcout("Quantity", "green"); cout << setw(i - 5);
		menu.gcout("Price", "green"); cout << endl;
		cout << setw(i) << "--------" << setw(i) << "----" << setw(i) << "------" << setw(i) << "--------" << setw(i - 5) << "-----" << endl;

		ifstream getfile("book", ios::in);
		while (!getfile.eof()) {
			getfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
			if (!getfile.eof()) {
				cout << setw(i) << cName << setw(i) << bName << setw(i) << aName << setw(i)
					<< quant << setw(i - 5) << cost << " $" << endl;
			}

		}
		getfile.close();
		do {
			if (menu.suggestExit() == 8) {
				system("cls");
				showOptions();
				break;
			}
			else {
				exit;
				break;
			}
		} while (1);
	}
	else if (res == seller_options.size()) {
		system("cls");
		Main_menu(1);
	}
}

void Seller::setNewBook() {
	string bname, author, ISBN, category;
	string quantity;string vnumb; float price = 0; bool org = 0;
	system("cls");
	cout << "\n\n\n";
	menu.gcout("\t\tEnter book name: ", "litblue"); cin >> bname;cout << endl;
	menu.gcout("\t\tEnter author name: ", "litblue"); cin >> author;cout << endl;
	menu.gcout("\t\tEnter ISBN: ", "litblue"); cin >> ISBN;cout << endl;
	menu.gcout("\t\tEnter category name: ", "litblue"); cin >> category;cout << endl;
	try {
	menu.gcout("\t\tEnter version number: ", "litblue"); cin >> vnumb;cout << endl;
	menu.gcout("\t\tEnter quantity: ", "litblue"); cin >> quantity;cout << endl;
	menu.gcout("\t\tEnter price: ", "litblue"); cin >> price;cout << endl;
	menu.gcout("\t\tEnter 1 if it's original or 0 if it's not: ", "litblue"); cin >> org;cout << endl;
	
		if (!stoi(vnumb)|| !stoi(quantity)) {
			throw exception();
		}
		else {
			int q = stoi(quantity);
			int v = stoi(vnumb);
		Book obj(bname, author, ISBN, v, category, q, price, org);
		if (obj.addBook() == 1) {
			showOptions();
		}
		}
	}
	catch (exception &error) {
	cout << endl;
	system("cls");
	cout << "Error No 109\nYour data was not added succesfully,enter them again\n" << error.what()<<endl;
	Sleep(3000);
	system("cls");
	showOptions();
	}
	//===========================================================================================	
}

void Seller::setNewE_Book() {
	string bname, author, ISBN, category;
	float filesize;string vnumb; float price = 0;
	system("cls");
	cout << "\n\n\n";
	menu.gcout("\t\tEnter book name: ", "litblue"); cin >> bname;cout << endl;
	menu.gcout("\t\tEnter author name: ", "litblue"); cin >> author;cout << endl;
	menu.gcout("\t\tEnter ISBN: ", "litblue"); cin >> ISBN;cout << endl;
	menu.gcout("\t\tEnter category name: ", "litblue"); cin >> category;cout << endl;
	try {
		menu.gcout("\t\tEnter version number: ", "litblue"); cin >> vnumb;cout << endl;
		menu.gcout("\t\tEnter filesize: ", "litblue"); cin >> filesize;cout << endl;
		menu.gcout("\t\tEnter price: ", "litblue"); cin >> price;cout << endl;

		if (!stoi(vnumb)) {
			throw exception();
		}
		else {
			int v = stoi(vnumb);
			E_Book obj(bname, author, ISBN, v, category,1, price, filesize);
			if (obj.addE_Book() == 1) {
				showOptions();
			}
		}
	}
	catch (exception &error) {
		cout << endl;
		system("cls");
		cout << "Error No 109\nYour data was not added succesfully,enter them again\n" << error.what() << endl;
		Sleep(3000);
		system("cls");
		showOptions();
	}
	//===========================================================================================	
}

int Seller::search_for(string inpt) {
	string cName, bName, aName, ISBN;
	int vNumber, quant; float cost;bool org;
	system("cls");
	int i = 16;
	cout << setw(i); menu.gcout("Category", "green"); cout << setw(i); menu.gcout("Name", "green"); cout << setw(i);
	menu.gcout("Author", "green"); cout << setw(i); menu.gcout("Quantity", "green"); cout << setw(i - 5);
	menu.gcout("Price", "green"); cout << endl;
	cout << setw(i) << "--------" << setw(i) << "----" << setw(i) << "------" << setw(i) << "--------" << setw(i - 5) << "-----" << endl;
	int d = 1;
	ifstream getfile("book", ios::in);
	while (!getfile.eof()) {
		getfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
		if (!getfile.eof()) {
			if (inpt == bName) {
				cout << setw(i) << cName << setw(i) << bName << setw(i) << aName << setw(i)
					<< quant << setw(i - 5) << cost << " $" << endl;
				d = 0;
				break;
			}
		}
	}
	getfile.close();
	if (d==0) {
		bool var = 0;
		do {
			cout << "\n\n\t\t\t";
			menu.gcout("Press ENTER to buy book", "litblue");
			cout << "\n\t\t\t";
			menu.gcout("Press ESC to go back\n", "litblue");
			int suggestions = _getch();
			string bvalue;
			if (suggestions == 13) {
				int numbOfBook;
				for (unsigned i = 0; ;) {
					cout << "\n\n\t\t\t";
					menu.gcout("Enter the number of book you want to buy", "litblue");
					cin >> numbOfBook;
					if (numbOfBook > quant||numbOfBook<=0) {
						cout << "\n\nSorry we have got " << quant << " book!";
					}
					else {
						deleteBook(bName, quant, numbOfBook);
						break;
					}
				}
				cout << "\n\n\t\t\t";
				system("cls");
				if (showPayOptions() == "money") {
					return ShowCheck("money", numbOfBook, cost);
					break;
				}
				else {
					return ShowCheck("credit", numbOfBook, cost);
					break;
				}
			}
			else if (suggestions == 27) {
				system("cls");
				return 1;
				break;
			}
			else {
				menu.gcout("\n\nPress correct key!", "yellow");
				var = 1;
			}
		} while (var == 1);
	}
	else {
		if (menu.suggestExit() == 8) {
			return 1;
		}
		else {
			exit;
		}
	}
}

void Seller::deleteBook(string & inpt, int &q, int &n)
{
	string cName, bName, aName, ISBN;
	int vNumber, quant; float cost;bool org;
	ifstream getfile("book", ios::in);
	ofstream outfile(".arch", ios::out);
	ofstream cashfile("shop", ios::app);
	while (!getfile.eof()) {
		getfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
		if (!getfile.eof()) {
			if (inpt == bName) {
				if (quant > n) {
					outfile << cName << " " << bName << " " << aName << " " << ISBN << " " << vNumber << " "
						<< quant-n << " " << cost << " " << org << endl;
					cashfile << bName <<" "<< n << " " << cost << endl;
				}
				else {
					cashfile << bName << " " << n << " " << cost << endl;
				}
			}
			else {
				outfile << cName << " " << bName << " " << aName << " " << ISBN << " " << vNumber << " " 
					<< quant << " " << cost << " " << org << endl;
			}
		}
	}
	cashfile.close();
	outfile.close();
	getfile.close();

	ofstream newFile("book");
	ifstream oldfile(".arch",ios::in);
	while (!oldfile.eof()) {
		oldfile >> cName >> bName >> aName >> ISBN >> vNumber >> quant >> cost >> org;
		if (!oldfile.eof()) {
			newFile << cName << " " << bName << " " << aName << " " << ISBN << " " << vNumber << " "
				<< quant << " " << cost << " " << org << endl;
		}
	}
	oldfile.close();
	newFile.close();
}

int Seller::ShowCheck(string s,int &q, float &c) {
	system("cls");
	if (s == "money") {
		menu.gcout("\n\n\t\t- - - Thank you for purchasing from our shop - - -\n", "litblue");
		menu.gcout("\n\n\t\t\tBook's price: ", "litblue"); cout << c<<"$";
		menu.gcout("\n\n\t\t\tDiscount for today: ", "litblue"); cout << "0 %";
		menu.gcout("\n\n\t\t\tTotal price: ", "litblue"); cout << q*c<<"$";
		menu.gcout("\n\n\t\t\tCredit card interest: ", "litblue"); cout << "0 %";
		if (menu.suggestExit() == 8) {
			return 1;
		}
		else {
			exit;
		}
	}
	else if (s == "credit") {
		menu.gcout("\n\n\t\t- - - Thank you for purchasing from our shop - - -\n", "litblue");
		menu.gcout("\n\n\t\t- - - We have got 10 % interest for credit card paying - - -\n", "red");
		menu.gcout("\n\n\t\t\tBook's price: ", "litblue"); cout << c << "$";
		menu.gcout("\n\n\t\t\tDiscount for today: ", "litblue"); cout << "0 %";
		menu.gcout("\n\n\t\t\tTotal price: ", "litblue"); cout << q*c*1.1 << "$";
		menu.gcout("\n\n\t\t\tCredit card interest: ", "litblue"); cout << "10 %";
		if (menu.suggestExit() == 8) {
			return 1;
		}
		else {
			exit;
		}
	}
	
	cout << "\n\t\t\t";
}

void Seller::createMembership() {
	string name, surname, dob, username, password;
	//these are temporary variables only for the first time users
	int age; 
	float salary;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tEnter Seller's name: ", "litblue");
	cin >> name;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tEnter Seller's surname: ", "litblue");
	cin >> surname;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tEnter age: ", "litblue");
	cin >> age;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tEnter date of birth(dd.mm.yy): ", "litblue");
	cin >> dob;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tEnter username: ", "green");
	cin >> username;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tUsername: ", "green"); cout << username;
	cout << endl << endl; menu.gcout("\tEnter password: ", "green");
	cin >> password;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tUsername: ", "green"); cout << username;
	cout << endl << endl; menu.gcout("\tPassword: ", "green"); cout << password;
	cout << endl << endl; menu.gcout("\tEnter salary: ", "green");
	cin >> salary;
	system("cls");
	cout << "\t\t\t\n\n\n";menu.gcout("--- This page is only for shop owner ---\n", "litblue");
	cout << endl << endl; menu.gcout("\tName: ", "litblue"); cout << name;
	cout << endl << endl; menu.gcout("\tSurname: ", "litblue"); cout << surname;
	cout << endl << endl; menu.gcout("\tAge: ", "litblue"); cout << age;
	cout << endl << endl; menu.gcout("\tDate of birth: ", "litblue"); cout << dob;
	cout << endl << endl; menu.gcout("\tUsername: ", "green"); cout << username;
	cout << endl << endl; menu.gcout("\tPassword: ", "green"); cout << password;
	cout << endl << endl; menu.gcout("\tSalary: ", "green"); cout << salary;
	cout << endl << endl;
	cout << "\t\t Please choose the following options" << endl;
	cout << "\n\t\tPress ENTER - to submit data";
	cout << "\n\t\tPress BACKSPACE - to reset data";
	cout << "\n\t\tPress ESC - to exit";
	int q;
	do {
		q = 0;
		int c = _getch();
		if (c == 13) {
			ofstream seller("seller.dat");
			seller << username << " " << password << " " << age << " " << dob << " " << name << " " << surname << " " << salary<< endl;
			seller.close();
			system("cls");
			cout << "\n\n\n\n\t\tYour data successfully submitted!";
			Sleep(1000);
			system("cls");
			Main_menu(2);
		}
		else if (c == 8) {
			this->createMembership();
		}
		else if (c == 27) {
			system("cls");
			Main_menu(2);
		}
		else {
			cout << endl << "Use appropriate keys";
			q = 1;
		}
	} while (q == 1);

}

string Seller::showPayOptions()
{
	int lv=menu.showChoiceMenu(0,payOpts);
	if (lv == 1) {
		return string("money");
	}
	else {
		return string("credit");
	}
	
}
